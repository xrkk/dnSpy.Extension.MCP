"""VM-local CHK-018 regression against tools/list's actual published schemas."""
import json,sys,uuid
from pathlib import Path
import jsonschema
sys.path.insert(0,r'C:\Tools\dnspy-mcp-edit-tests\vm-726395b\repo')
from dnspy_mcp import DnSpyClient
root=Path(__file__).parent;arch=sys.argv[1];c=DnSpyClient('http://127.0.0.1:15378/mcp',timeout=60)
rows=[];tx=None;rev=0
try:
 c.initialize();tools={t['name']:t for t in c.list_tools()['tools']}
 (root/f'tools-{arch}.json').write_text(json.dumps(tools),encoding='utf-8')
 for tool in ('edit_begin','edit_apply','edit_import','edit_resource_import'):
  cap=tools[tool]['outputSchema']['oneOf'][0]['properties']['result']['properties']['capacity']
  assert {'review_tombstone_entries','review_tombstone_bytes'} <= set(cap['properties'])
  assert cap['additionalProperties'] is False
 def call(tool,args):
  global tx,rev
  args={'request_id':str(uuid.uuid4()),**args} if tool.startswith('edit_') else args
  r=c.call_tool_json(tool,args);rows.append(dict(tool=tool,args=args,response=r))
  if tool=='edit_begin':tx=r['result']['transaction']['transaction_id']
  if 'transaction' in r.get('result',{}):rev=r['result']['transaction']['work_revision']
  if tool.startswith('edit_'):
   assert r['ok'],r
   jsonschema.Draft202012Validator(tools[tool]['outputSchema']).validate(r)
  print('PASS actual complete '+tool,flush=True);return r
 fixture=str(root/('Chk018'+arch+'.exe'))
 call('open_files',{'paths':[fixture]})
 call('edit_begin',{'assembly_name':'Chk018'+arch})
 call('edit_apply',dict(transaction_id=tx,expected_revision=rev,operation=dict(kind='managed_resource_add',name='chk018-inline',data_base64='AQIDBA==')))
 path=Path(r'C:\Tools\MefCheck')/('chk018-'+arch)/'resource.bin';path.parent.mkdir(exist_ok=True);path.write_bytes(b'\1\2\3\4')
 call('edit_resource_import',dict(transaction_id=tx,expected_revision=rev,vm_path=str(path),resource_type='linked',resource_name='chk018-linked'))
 call('edit_rollback',dict(transaction_id=tx,expected_revision=rev));tx=None
 print('PASS CHK-018 '+arch,flush=True)
finally:
 if tx:
  try:c.call_tool_json('edit_rollback',dict(request_id=str(uuid.uuid4()),transaction_id=tx,expected_revision=rev))
  except Exception as e:print('CLEANUP_ERROR',str(e),flush=True)
 c.close();(root/f'actions-{arch}.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
