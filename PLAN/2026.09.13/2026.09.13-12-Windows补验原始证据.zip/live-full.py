import sys,json,uuid,hashlib,ctypes,os
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent/'repo'))
from dnspy_mcp import DnSpyClient
import jsonschema
root=Path(__file__).parent
arch=sys.argv[1]
log=open(root/f'live-{arch}-full-actions.jsonl','w')
schema_errors=[]
schemas=json.loads((root/'repo/Editing/Contracts/p03-tool-schemas.json').read_text())
c=DnSpyClient('http://127.0.0.1:15378/mcp',client_name='vm-resource-recheck',timeout=90);c.initialize()
def call(tool,args,ok=True):
 args={'request_id':str(uuid.uuid4()),**args} if tool.startswith('edit_') else args
 try:r=c.call_tool_json(tool,args)
 except Exception as e:
  s=str(e);r=json.loads(s[s.index('{'):]) if '{' in s else {'ok':False,'exception':s}
 log.write(json.dumps({'tool':tool,'args':args,'response':r})+'\n');log.flush()
 if ok: assert r.get('ok',True),r
 if tool in schemas and ok:
  for e in jsonschema.Draft202012Validator(schemas[tool]['outputSchema']['oneOf'][0]).iter_errors(r):
   msg=tool+' '+str(list(e.absolute_path))+': '+e.message;schema_errors.append(msg);print('SCHEMA_FAIL '+msg,flush=True)
 return r
try:
 fixture=r'C:\Tools\mcp-repo\tests\fixtures\bin\ImportHost\ImportHost.exe'
 if arch=='x86':fixture=fixture.replace('ImportHost\\ImportHost.exe','ImportHost-x86\\ImportHost.exe')
 call('open_files',{'paths':[fixture]})
 begin=call('edit_begin',{'assembly_name':'ImportHost'});tx=begin['result']['transaction']['transaction_id'];rev=0
 inp=Path(r'C:\Tools\MefCheck')/('vm-726395b-'+arch);inp.mkdir(exist_ok=True)
 data=bytes(range(256))*8192;p=inp/'input.bin';p.write_bytes(data);sha=hashlib.sha256(data).hexdigest()
 for bad in (str(root/'bundle.zip'),str(inp)):
  r=call('edit_resource_import',dict(transaction_id=tx,expected_revision=rev,vm_path=bad,resource_name='bad'),False);assert not r.get('ok'),r
 print('PASS outside-root and directory rejection',flush=True)
 for typ in ('embedded','linked','win32'):
  r=call('edit_resource_import',dict(transaction_id=tx,expected_revision=rev,vm_path=str(p),resource_name='vm-'+typ,resource_type=typ))['result'];rev=r['transaction']['work_revision'];identity=r['import'];assert identity['length']==len(data) and identity['sha256']==sha
  print('PASS import '+typ+' id='+identity['file_id'],flush=True)
 review=call('edit_review',dict(transaction_id=tx,expected_revision=rev))['result']['review']
 commit=call('edit_commit',dict(transaction_id=tx,expected_revision=rev,review_id=review['review_id'],review_revision=rev,confirmed_risk_ids=review['required_confirmation_ids']))
 print('PASS review/commit complete output schemas',flush=True)
 for typ in ('embedded','linked','win32'):
  args=dict(assembly_name='ImportHost',resource_name='vm-'+typ,resource_type=typ,output_path='edit-output/vm-726395b-'+arch+'/'+typ+'.bin')
  out=call('edit_resource_export',args)['result']['export'];f=Path(out['path']);assert f.read_bytes()==data and out['sha256']==sha and out['length']==len(data)
  out2=call('edit_resource_export',args)['result']['export'];assert f.read_bytes()==data and out2['file_id']
  assert not list(f.parent.glob(f.name+'.tmp-*'))
  print('PASS export/replace/collision/temp-clean '+typ,flush=True)
 print('FUNCTIONAL_PASS live '+arch+' schema_failures='+str(len(schema_errors)),flush=True)
finally:c.close();log.close()
