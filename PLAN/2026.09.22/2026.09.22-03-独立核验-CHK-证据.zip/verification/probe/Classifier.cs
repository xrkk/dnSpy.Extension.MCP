using System; using System.Linq; using System.Collections.Generic; using dnSpy.Extension.MCP.Debugger;
static class Classifier {
	static readonly int[] StrongNameFailureHResults = { unchecked((int)0x8013DE1A), unchecked((int)0x8013141A) };

	static readonly System.Text.RegularExpressions.Regex LoaderAssemblyIdentityRegex = new(
		@"['\u201C\u2018](?<name>[^'\u201C\u201D\u2018\u2019,]+),\s*Version=(?<version>[0-9.]+)(?:,\s*Culture=[^,]+)?,\s*PublicKeyToken=(?<pkt>[0-9a-fA-F]{16})['\u201D\u2019]",
		System.Text.RegularExpressions.RegexOptions.CultureInvariant | System.Text.RegularExpressions.RegexOptions.Compiled);

	/// <summary>Full classification with the binding-failure criteria (PLAN-CHANGE 2026.09.22).
	/// A strong-name binding failure carries no loader module attribution (the throwing module
	/// resolves to null or the caller's stack top), so attribution alone cannot gate it. The
	/// trusted form is (strong-name HRESULT + loader-authored identity) PLUS, when attribution
	/// is absent, the reference-closure differential: the rejected identity must be a
	/// strong-named AssemblyRef of the launch host's own metadata AND absent from the session's
	/// loaded-module set. Both are debugger facts sample code cannot forge: an assembly the
	/// runtime actually loads clears the differential, and an identity the host never
	/// references is rejected.</summary>
	internal static StrongNameRejectionFacts? ClassifyLoaderStrongNameRejection(string? moduleName, int? hResult, string? message,
		string? hostTargetPath, IReadOnlyCollection<string>? loadedModuleNames) {
		if (hResult is null || !StrongNameFailureHResults.Contains(hResult.Value) || string.IsNullOrEmpty(message))
			return null;
		var match = LoaderAssemblyIdentityRegex.Match(message);
		if (!match.Success)
			return null;
		var name = match.Groups["name"].Value.Trim();
		var version = match.Groups["version"].Value.Trim();
		var token = match.Groups["pkt"].Value.ToLowerInvariant();
		bool loaderAttributed = string.Equals(moduleName, "mscorlib", StringComparison.OrdinalIgnoreCase)
			|| string.Equals(moduleName, "System.Private.CoreLib", StringComparison.OrdinalIgnoreCase);
		if (!loaderAttributed) {
			if (hostTargetPath is null || loadedModuleNames is null)
				return null;
			if (loadedModuleNames.Any(loaded => string.Equals(loaded, name, StringComparison.OrdinalIgnoreCase)))
				return null;
			if (!HostReferencesStrongIdentity(hostTargetPath, name, token))
				return null;
		}
		return new StrongNameRejectionFacts {
			LoaderModule = loaderAttributed ? moduleName! : "binding-failure",
			HResult = hResult.Value,
			AssemblyName = name,
			AssemblyVersion = version,
			PublicKeyToken = token,
		};
	}

	static bool HostReferencesStrongIdentity(string hostPath, string name, string token) {
		try {
			using var host = dnlib.DotNet.ModuleDefMD.Load(hostPath);
			foreach (var reference in host.GetAssemblyRefs()) {
				if (!string.Equals(reference.Name, name, StringComparison.OrdinalIgnoreCase))
					continue;
				// The ref may carry an 8-byte token or the full public key; dnlib's Token
				// derives the token from either form.
				var refToken = reference.PublicKeyOrToken?.Token?.Data;
				if (refToken is null || refToken.Length != 8)
					continue;
				var hex = string.Concat(refToken.Select(b => b.ToString("x2")));
				if (string.Equals(hex, token, StringComparison.OrdinalIgnoreCase))
					return true;
			}
			return false;
		}
		catch {
			return false;
		}
	}

}