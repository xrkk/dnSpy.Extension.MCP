static class ThreadProjection {
 public sealed class Thread { public int Id = 1; }
 static string MintThreadHandle(Thread thread, int epoch) => "th-" + thread.Id;
 public static string? Project(Thread? eventThread) { int eventPauseEpoch=1;
 var threadHandle = eventThread is not null ? null : MintThreadHandle(eventThread, eventPauseEpoch);
 return threadHandle; }
}