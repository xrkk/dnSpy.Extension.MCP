from pathlib import Path
import json
from jsonschema import Draft202012Validator
base=Path(__file__).resolve().parent
root=base.parents[1]
text=(base/'probe-run-4.txt').read_text()
result=json.loads(text[text.index('{\n'):])
(base/'probe-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
schema=json.loads((root/'tests/debug/contracts/dnspy.debug.v1.schema.json').read_text())
errors=[e.message for e in Draft202012Validator({'$ref':'#/$defs/event_exception','$defs':schema['$defs']}).iter_errors(result['exception_payload'])]
(base/'schema-result.json').write_text(json.dumps({'schema':'tests/debug/contracts/dnspy.debug.v1.schema.json#/$defs/event_exception','actual_payload':result['exception_payload'],'errors':errors,'valid':not errors},ensure_ascii=False,indent=2))
assert errors
assert result['sample_module_synthetic_message_accepted'] is True
assert result['loader_module_without_host_or_loaded_set_accepted'] is True
assert result['present_thread_projection'] is None
assert result['absent_thread_exception']=='NullReferenceException'
assert result['evicted_cursor_evidence_consumed'] is True
assert result['evicted_evidence_cursor'] < result['oldest_returned_event_cursor']
print('Independent counterexamples reproduced; this is a failing product verdict, not a passing acceptance run.')
