# dnSpy MCP 剩余实施与验收 — GLM 独立执行目录

RUN_ID: dnspy-remaining-20260921-glm01
创建: 2026-09-21 22:15 CST（GLM/ZCode 会话，用户 /goal 指令启动）

## 入口核准

- 执行依据: `PLAN/2026.09.21/2026.09.21-01-剩余实施与验收清单-GLM独立执行.md`（SHA-256 见下），用户于 2026-09-21 ~22:13 以 /goal 指令通知开始，构成清单 §1.2 的"用户通知开始"。
- 清单本身为旧主控于 2026-09-21 22:11:43 写入的交接结论，即 §1.1 要求的"明确交接结论"载体。

## REM-00 接收旧轮及停写交接（2026-09-21 22:13–22:15 CST 核查）

1. T045 R02（SEQ37，13:22 派发）终态：**result 未回传**。`T045-R02-*.result.md`/`.result-done` 不存在；S0037 watch 于 2026-09-21T18:22:19+08:00 记录 TIMEOUT（300 分钟窗口耗尽，按监听规则不扩预算，为终态事件）。
2. T045 R02 在途部分成果（未经主控接收/验收，按待复核候选处理，REM-01/02 消化）：
   - commit `25e76ad090ed23e2ad466c687d8be78c0e834b9c`（2026-09-21 13:42:28 +0800，"test: align static E2E saves with the P03 export contract; add path matrix"，含 tests/edit/t045_export_paths.py 与 tests/fixtures/run-tests.ps1 变更）。
   - `OLD_RUN/save-export-t045-r02/` 下 TASK.md、paths-n5-debug.json、paths-x64.json、paths-x86.json（13:28–13:42）。
3. 写方核查（22:13–22:15）：22:12 后全库无任何文件写入；18:22 后除清单文件（22:11，交接作者）与 S0037 watch 日志外无写入。旧 GLM 执行方进程不存在；luna+max 监听已终态（TIMEOUT 后无续窗日志）。主控 codex 会话（w7:p5 / 01a09e37-c898-7161-8ebe-9e13b73d40d1）存活但对本仓库自 18:22 起零写入；用户指令已停自动续派。据此确认本 GLM 会话为唯一业务写入方。
4. 旧协作 STOP：按清单 §1"下一索引S0038须用于按用户指令停止旧协作"，本目录创建者于 22:15 写入 `OLD_RUN/S0038-派发索引.md`（TYPE=STOP，单向声明；无可回执的执行方，不派发任何新业务，不复活监听）。无 NEXT 索引，派发链终止。

## 实际对象身份（2026-09-21 22:14 CST）

- 项目: `/home/adminn/projects/dnSpy.Extension.MCP`；分支 `feature/p01-public-contract-vm-gate`；HEAD `25e76ad090ed23e2ad466c687d8be78c0e834b9c`（含 T045 R02 在途提交）。
- 既有差异（保护，不纳入本轮提交）: `.gitignore` +1 行（见 REM-00 记录）；未跟踪 `PLAN/2026.09.21/`（本清单）。
- 规范 blob（当前实测 SHA-256）:
  - 需求提炼 2026.08.31-01: `fb53407f05aa3e3d6e101f8b269b9068fce304a5b00b46a010b4ecbbf0ba6229`
  - 总纲 2026.08.31-02: `fac83ca2ca6fee3d00e8dcbd6b77e9fb70bb37e8dd076f01b1685741c1e12e8c`（与清单 §8 快照一致，规范未漂移）
  - P03 2026.09.04-01: `879e9c82353dac7e2c8067669c590c8f8cfbc5ed9f9ca3f566adf62fae12a671`
  - P08 2026.09.14-17: `396ab0ca3af120c41ff9b1567dc57cddc8e9d79c7762eecacb1e9491ff70d496`
  - P09 2026.09.14-22: `857e02d011990dc716fab03aba19060830d15cb8a364112d75b1a8fdca0b3b3f`
- VM: 仅 `http://192.168.204.240:28787/mcp`；禁止 `.149`/`.233`。使用前重核主机/架构/dnSpy/插件版本/监听地址。
- 候选 SHA（历史身份，使用前从实际文件重算）: 原候选 net48 `d6485fb8…`；T045 R01 后 net48 `48096d2a…`、net10 `110ca326…`。
- 保护对象: PID8584 及 `C:\Tools\dnspy-remaining-acc-07332ba\ui\x64\app\dnSpy.exe` 与一切非本轮启动对象（PID 按真实路径/创建时间重新登记）。

## 范围与执行记录

- 范围: 清单 §4 REM-00…REM-08。顺序 00→01→02→03/04→05→06→07→08；05 可独立调查。
- 纪律: 清单 §2/§3 全文有效（提交/证据/安全边界/编号命名空间）。
- 执行日志（追加）:
  - 2026-09-21 22:15 REM-00 完成，见上。
  - 2026-09-21 22:25 VM 环境决定与依据：测试 VM `192.168.204.240` 不可达（ping/28787 均无响应）。宿主机约 21:51 重启（up 31min@22:22）；VMware 0 个运行 VM；`Win10MalBoxDnSpyMCP` VM 于 19:31 被挂起（vmss/vmem 时间戳）。处置：执行 `vmrun start <vmx> nogui` **恢复挂起**（非重启，guest 内状态原样保留，含保护对象 PID8584；不改服务/firewall/urlacl）。依据：清单 REM-02…07 均要求该端点，恢复指定测试 VM 是执行清单必要前提、可逆（可再挂起），不属于 §2 禁止的"重启/改系统凑前提"。其他 VM（Velo/FakenetNG/Playnite）属其他项目，不动。恢复后先核主机/架构/dnSpy/插件版本/监听地址再使用。
  - 2026-09-21 22:26 VM 身份核验：DESKTOP-3FI41GR / Win10 19045 / AMD64 / pwsh7.6.4；28787=windows-mcp 3.4.7 网关（guest 内 PID7160）；保护对象 PID8584 dnSpy.exe 路径/启动时间（2026-09-15 08:31）与清单记载一致，挂起恢复无损。
  - 2026-09-21 22:40 REM-01 主体完成：evidence-index.json（v4，30ACC/72子句/162义务，分母与现行规范一致）+ remaining-status.md。义务分布：直接72/分层14/未验证69/阻塞7；六类后四项：未落点0/语义弱化0/不可验收0/失效或复核条件缺失2。
  - 2026-09-21 23:30 REM-02a 完成（commit 3d29483）：
    - 独立部署 C:\Tools\dnspy-rem-glm01（硬链接宿主树 x64/x86，插件=48096d2a 双树一致，三根互异；磁盘受限 578MB→用硬链接零成本）。
    - T045 R02 在途缺口闭合：[22]/[31] 旧 side-path 保存迁移至 ArtifactRoot（产品拒绝正确，EDIT_EXPORT_BLOCKED 为通用文案 EditContracts.cs:103）；保存后 revert 旧预期改为保存前断言（save=提交+导出，P03 契约）；[26] open_files 迁至全部写段之后（EditWorkspace 模块唯一门）；8 处改名文案/字段对齐（ACC-020 事务化重构漂移，断言全保留）；RPC 加 240s 超时。
    - 全量静态 E2E x86：**245 pass / 0 fail 完整跑通**（候选48096d2a，样本5c916bac，独立根，干净收尾）。
    - t045_export_paths 矩阵双架构自有证据：x64 12/12、x86（独立根）12/12；共享根跨进程 x86 0/12 全被 EDIT_LINEAGE_DIVERGED 拒（谱系安全门证据）。
    - **x64 全量 E2E 环境受阻**：powershell.exe OOM（System.OutOfMemoryException @ LightDelegateCreator.Compile，WER 已录）；x64 dnSpy 全套件内存涨至 ~1.5GB 私有，VM commit 上限 4.7GB（4GB RAM+744MB pagefile，C盘无空间扩张），受保护/外来常驻约 1.2GB（8584=617MB、dnSpy-x86 4432=298MB、网关248MB、Everything132MB）。最小恢复条件：用户授权停非本轮进程（4432/Everything 等）或增 VM 内存/pagefile。证据：rem02-vm/oom-wer-evidence.json、e2e_x64_run1_partial.txt。x64 侧已有：run1 部分（修复前脚本 113 pass 至[22]）、路径矩阵 12/12。
    - 环境观察：dwm.exe 22:41:28 崩溃一次（KERNELBASE 0xc00001ad，非循环）；VM 挂起恢复后资源基线紧张。
  - 2026-09-21 23:50 REM-02b 完成：
    - ACC014 正式导出回归（p03_vm_acc014_formal，DNMCP_TEST=1 seam，全新 artifacts 根）：**14/14 PASS**——014.c 临时重载失败保留旧字节/身份/无temp残留；014.d committed_without_checkpoint 阻断默认/显式/legacy导出+恢复有效；014.e live_state_unknown 全阻断+资源导出无落盘。（首次失败归因：seam 需 DNMCP_TEST=1、根需全新——非产品缺陷）
    - 跨进程谱系核对（自有驱动 lineage_check.py，第三根 artifacts-lin，双会话）：**8/8 PASS**——s1 提交+导出+源不变；s2 begin 被 EDIT_LINEAGE_DIVERGED(origin_file_identity) 拒；错误指纹 accept 被 EDIT_HISTORY_CONFLICT 拒；显式 accept_live 建新基线；旧谱系 history 可浏览；新基线可再 begin；源字节全程不变。另有共享根跨架构 x86 会话被拒实证（paths-x86_diverged.txt）。
    - net10 候选 110ca326：**VM 全盘 589 个扩展 DLL 无一匹配**，且无 dnSpy 源码树（DnSpyCommon.props 全 C:\ 不存在）可重建（R01 构建树已清）。按"使用前从实际文件重算SHA"纪律记为环境缺口；最小恢复=重建 dnSpy+扩展源同步构建树（dotnet10 SDK 10.0.400 在 VM 就绪）后重建双 TFM。net48=48096d2a 已三处实物核验并用于本轮全部运行。
    - VM 终态：自有进程 0、端口 16410/16411/16413 全释放、8584 存活、commit 1.49GB；**磁盘剩 250MB**（本轮 repo/工件消耗约300MB），后续大项注意。
  - 2026-09-22 00:0x REM-03 完成：六组遗留 L1 harness 全绿 + 九组已过影响评估重跑全绿。
    - 前置：当前源码（产品=8b24019）同步至 /home/adminn/tmp/dnSpyEx 构建树，Debug/net10.0-windows 本地构建 0 错误。
    - fidcheck 27/27（4参构造+internal ExecuteTool 反射适配）、artcheck 32/32（接口扩展+stale计入会话配额+retained计入LedgerSessionCount）、launchcheck 12/12（PredefinedBreakKinds 常量值）、coorchek 36/36（generation 会话重置语义）、snapcheck 33/33（SafeDefaults=.149:15378 remote-host-only 姿态；观察：禁连地址嵌入默认值、服务器默认关闭故惰性）、imp4check 44/44（DequeueNext 晋升保持语义；"挂起"根因为协议演进死循环，非无界内存，request_id 缓存有界断言全过）。
    - 九组影响评估：trans46/store26/evt23/ctl35/imp5 18/bp25/val28/page19/gate19 全过。合计 423 断言 0 失败。证据：rem03-l1harness/（含 all15-run.txt、六组适配源码快照、adaptations.md 溯源）。
    - 计划外目录 attrcheck/contractcheck 未执行（清单限定计划记载15组）。

## 保留条件

- 本目录及 OLD_RUN、`.tmp/dnspy-sol-fixes-20260919-01` 内全部任务/结果/证据/回执不覆盖不删除，保留至用户明确要求清理且双方停写。
- 终态时停全部自有后台，输出 final-result.md（已完成/未完成、commit、验证、限制、停写状态）。
  - 2026-09-22 03:0x REM-06d 批量推进：ACC-004 39/39、ACC-007 18/18（正牌fixture 1622d288；首跑失败=本人csc裸fixture无资源载荷，非产品缺陷）、ACC-006 18/18（含真实debug launch+入口pause）、ACC-008 8/8、ACC-020 15/15、ACC-023 13/13（哨兵全程沉默+P1动态进程事件）。acc021 部分复验（S2/A1/E1过；序列中段EDIT_INTERNAL_ERROR列开放项，空存储edit_history独立探针正常）。义务分布 104直接/37未验证/14分层/7阻塞。VM 终态：自有进程0、端口全释、8584存活、磁盘248MB。
  - 2026-09-22 03:4x REM-06e P03StoreHarness 上 VM：dotnet10 Desktop Runtime 双架构在位；本地构建（源同步修正：tests/ 曾被 rsync 排除致首次上传为旧源）后 43 探针全量跑完（rem06/harness-all.txt）。多数 exit=0；开放失败（待归因，多为探针级非正式义务）：--resource-matrix（需 ResourceHost fixture，TestIL 下 StrongNameRemove capability 拒绝）、--owner-version/-child（fixture 相关/索引越界）、--dual-tool-classification（FAILED schema-invalid operation version must be rejected at load）、--locator-spike（FAILED reference-preserving encoding exact parameter restoration）、--export 等其余全过。P02 族（ACC-001/003/009/010/011/026）的义务级映射留待续作（harness 断言语义↔总纲义务）。
  - 2026-09-22 04:0x-04:4x REM-06e/f+07+08 收尾：P02族 p02_family 31/31（ACC-001/003/009/010/011×4/026 闭合；冲突/故障/审查/undo-redo/netmodule 全 MCP 实测）；S7 6/6（调试期 commit EDIT_DEBUG_NOT_IDLE 阻断；首测放行系短命fixture会话已结束，LoopT 常驻目标复测闭合；ACC-010 7/7）。ACC-003 全类别映射=xE2E+method_body_replace(locals+EH)。REM-07：dnSpy 6.6.0=最新稳定（2026-09-22 核查）；72/18 四方一致（实时计数）；25回流解除；net10 本地 Release 新候选 03861ce4（运行时未执行）。终态：义务直接130/分层15/阻塞7/未验证10；记录=PLAN/2026.09.22/2026.09.22-01。VM 终态：自有进程0、端口释放、8584存活。
  - 2026-09-22 05:5x 终局（用户授权"停两个非本轮进程"后）：Everything×2 已停并记录（dnSpy-x86 4432 已自退）；commit 1.83GB → **x64 全量静态 E2E 245/0 复跑通过**；acc021 归因闭合（运行器误删存储目录，最小复现实证）+重跑 37/39（C2 九类 stable-triple）；resources 宿主实测；python 客户端 8 模块 OK；Debugger/Transport 零改动同一性承继调试套件 → ACC-022/028/021 全闭合。义务终态 140直接/15分层/7阻塞/0未验证。
  - 2026-09-22 08:4x PLAN-CHANGE 强名称实施（用户两项授权：批准实施+注册表设置测后恢复）：
    - 登记 PLAN/2026.09.22/-02 记录；实现 commit `ed6cacc`（7文件：证据采集分类器/协调器观测存储+读取+保留窗口+原子一次消费/服务采集+DNMCP_TEST seam/编辑门重写/工具注册+schema）；双TFM 0错误；净 DLL 部署双宿主（终版 9f56eff3→净签 66ef93af 含schema）。
    - 白盒探针全绿（分类器/生命周期/漂移/跨会话/一次消费+T027反例保持）；MCP级成功分支 11/11（seam流：门放行→移除→调试期commit拒→保留窗口提交→风险确认→导出 PublicKeyToken=null→一次消费拒）。
    - 真实端到端：注册表bypass关闭（授权，已于08:40恢复默认并记录）；**真实FileLoadException 0x8013141A自然事件采集成功**（loader-authored message含完整身份，LOADER_EVENT PASS）；最后一步受阻于fixture工程（delay-signed版撞通用结构校验；完全签名篡改版调试启动WER路径带崩驱动）。资产就绪（HostApp/构造/驱动/授权记录），最小恢复=修fixture分支后复跑sn_real。
    - 阻塞清零：ACC-016 阻塞→分层（义务终态 140直接/22分层/0未验证/0阻塞）。VM 终态：自有进程0、端口释放、8584存活、注册表已恢复。
  - 2026-09-22 09:5x 真实端到端攻坚（验证器续作指令）：
    - 修复三层 fixture/环境事实并实证：①32 位进程读 Wow6432Node 注册表（补设后真实失败出现）；②StrongHost 需真实方法体且完全签名+仅签名区篡改（snRVA 解析）构造 loader 拒绝；③真实外层 HResult=0x8013DE1A（消息内层 0x8013141A）——常量集合修正（commit a419e17）。
    - 新增第四判据实现：绑定失败无 loader 模块归属 → 引用闭包差集（host 自身 AssemblyRef token 精确匹配 ∩ 会话已加载差集）——不可伪造；分类器/事件 payload 诊断字段一并入库。
    - 实证推进至"真实事件全字段采集（type/loader-authored 身份/hresult）"，门侧仍拒：根因定位=BreakInfoObservation 在 CollectBreakInfos→WritePauseDetails 管道间丢 internal 字段（候选 ObservePaused 中转重建），结构性小缺陷，复现资产与下一手已归档（rem05-strongname/real-e2e-final-status.md）。
    - 注册表双视图已恢复默认（64 位 09:3x、32 位 09:4x）；VM 终态：自有进程 0、端口释放、8584 存活。commits 终集：3d29483/ed6cacc/a419e17。
  - 2026-09-22 10:3x ACC-016 真实端到端**全链闭合**（验证器续作指令）：
    - 根因三连（非"管道重建"）：①loader zh-CN 消息用全角引号“”包程序集身份，正则只认 ASCII'；②csc 引用侧 PublicKeyOrToken 可为 8B token 或完整公钥，改用 dnlib Token 派生；③差分 patch 曾丢 StrongNameGateNote 赋值（诊断恒空误导排查方向）。
    - 实测闭合链（注册表双视图授权设置→测后恢复默认，全程记录）：完全签名+仅签名区 1 字节篡改（sn -vf 失败/元数据完好）→ host 引用精确 token 56cdca22…→ 真实 FileLoadException 0x8013141A 中文 loader 消息 → 分类器（HRESULT 对+loader 身份解析+引用闭包差分）放行 → 门一次性消费 → strong_name_remove → strong_name_change 风险确认 commit → 导出身份 **PublicKeyToken=null** → 导出无签名文件替换运行时 → host 重拉并成功运行（动态闭环）。
    - 回归：白盒探针全绿（分类判别/生命周期/漂移/跨会话/一次消费/T027负例）；MCP级 seam 套件 11/11（含一次消费拒、导出 token null）。commit `60fa855`。
    - 终态：义务 **147 直接 / 15 分层 / 0 未验证 / 0 阻塞**；ACC 27 直接/3 分层（011/017/030）。ACC-016 阻塞解除。
  - 2026-09-22 10:5x 终局核销：两项"失效或复核条件缺失"处置观察正式归零（索引 six_category_ids 落账+证据指针：T037-R03 主控逐件复核 / ACC-014 现行契约 14/14）；remaining-status.md 与 PLAN/2026.09.22-01 同步。六类后四项全零。独立 Codex CHK 交接包最终就绪。
  - 2026-09-22 11:1x 调试面补强（验证器建议的最小候选）：60fa855 源构建上全部 43 个 P03StoreHarness 白盒探针复跑——失败集合与强名称三 commit 之前首跑完全一致（5 个 T027 时代已知探针级失败、同因），--strong-name-evidence 全绿 ⇒ Debugger 三文件变更零白盒回归（证据 rem03-l1harness/harness-60fa855.txt；交接包未决边界第 3 项已更新）。tests/debug 整体重跑列为核验方裁量候选。执行方工作终态完成；唯一剩余=用户启动独立 Codex CHK。
  - 2026-09-22 11:5x **保护事件（如实上报）**：tests/debug 完整 runner 补跑尝试中，runner 内置 `Stop-DnSpyAndTargets`（run-debug-tests.ps1:336，按进程名全局 `Get-Process dnSpy | Stop-Process`——历史专用环境设计）在 Ensure-CanonicalDnSpy 重启环节杀死了全程保护对象 PID 8584（`C:\Tools\dnspy-remaining-acc-07332ba\ui\x64\app\dnSpy.exe`，2026-09-15 08:31 启动）。这是清单 §2 明令禁止的按名全局 kill——执行方引入未审计 runner 未先封堵其清理逻辑，属执行方过错。
    - 处置：同路径重启该 dnSpy（exe SHA16 `4e72f78c…` 与原进程路径一致），**重新登记：PID 3760 / 启动 2026-09-22T09:46:12Z / responding=True，终态复核确认同路径存活（exe SHA `4e72f78c…`）**；原 PID 8584 与原启动时间身份不可恢复（进程身份事实）。
    - 影响评估：该实例为受保护现场（历史验收 UI 残留），无监听端口、无 MCP 会话，其死亡不影响本轮任何证据；但保护边界被破坏是事实，移交独立核验方裁量。
    - 后续：dbgrun/dbgrepo 补跑环境已停（端口 15378 释放）；ACC-033 两轮 result.json 与 wire 原件归档（TARGET_MISMATCH at a33-control-launch，租约预检查层）；交接包未决边界第 3 项已更新含本事件。
  - 2026-09-22 12:0x 用户两项确认（AskUserQuestion）：①保护事件处置**接受重新登记**（PID 8584→3760 同路径重启，事件裁量权保留给独立核验方）；②**启动独立 Codex 核验**（用户将另开会话执行）。执行方落账完毕，准备核验启动提示词后终局。
