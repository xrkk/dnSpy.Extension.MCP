using System;
using System.Collections.Generic;
using System.Linq;
using dnSpy.Extension.MCP.Debugger;

int pass = 0, fail = 0;
void T(string label, bool cond) { if (cond) pass++; else { fail++; Console.WriteLine("FAIL " + label); } }

// ---- DebugHandleStore ----
int closed = 0;
int seq = 0;
var hs = new DebugHandleStore(() => "h" + (++seq), e => closed++);
var h1 = hs.Allocate("s1", 1, 2, "thread-ctx");          // pause 绑定
var h2 = hs.Allocate("s1", 1, null, "module-ctx");        // generation 绑定
var h3 = hs.Allocate("s1", 2, null);                      // 新 generation
T("hs.resolve-ok", hs.TryResolve(h1, "s1", 1, 2, out var e1) && (string)e1.Payload == "thread-ctx");
T("hs.resolve-wrong-epoch", !hs.TryResolve(h1, "s1", 1, 3, out _));
T("hs.resolve-null-epoch-mismatch", !hs.TryResolve(h1, "s1", 1, null, out _));
T("hs.resolve-gen-bound", hs.TryResolve(h2, "s1", 1, null, out _) && !hs.TryResolve(h2, "s1", 2, null, out _));
T("hs.resolve-wrong-session", !hs.TryResolve(h2, "sX", 1, null, out _));
// continue:epoch 失效 → h1 关闭恰一次,h2 不受影响
T("hs.inval-epoch", hs.InvalidatePauseEpoch("s1", 1, 2) == 1 && closed == 1);
T("hs.closed-dead", !hs.TryResolve(h1, "s1", 1, 2, out _));
T("hs.sibling-alive", hs.TryResolve(h2, "s1", 1, null, out _));
// 重复失效零效果(关闭恰一次)
T("hs.inval-epoch-again", hs.InvalidatePauseEpoch("s1", 1, 2) == 0 && closed == 1);
// restart:generation 失效
T("hs.inval-gen", hs.InvalidateGeneration("s1", 1) == 1 && closed == 2 && !hs.TryResolve(h2, "s1", 1, null, out _));
// session 终局全关
hs.Allocate("s1", 2, 5);
T("hs.inval-session", hs.InvalidateSession("s1") == 2 && closed == 4);
T("hs.unknown-handle", !hs.TryResolve("nope", "s1", 1, null, out _));

// ---- DualLaneQueue ----
using var dq = new DualLaneQueue();
var ctl = new List<DualLaneQueue.Ticket>();
for (int i = 0; i < 8; i++) {
	bool okc = dq.TryEnterControl(out var t);
	T($"dq.ctl{i}", okc && t != null);
	if (t != null) ctl.Add(t);
}
T("dq.ctl-9th", !dq.TryEnterControl(out _));
var gen = new List<DualLaneQueue.Ticket>();
for (int i = 0; i < 56; i++) dq.TryEnterGeneral(out var t2);
T("dq.gen-full", dq.Counts == (8, 56, 64));
T("dq.gen-57th", !dq.TryEnterGeneral(out _));
// 释放一个 control → 第 9 个可入
ctl[0].TryRelease();
T("dq.ctl-after-release", dq.TryEnterControl(out var t9) && t9 != null);
// 优先级:control 先于 general;lane 内 FIFO
// 2026-09-21 适配: DequeueNext 现为"晋升 running 并保持到释放"语义(旧语义弹出即缩队)。
// 遍历协议 = 取当前 running → 记录 → TryRelease(移出并晋升下一张) → 直到 null。
var order = new List<(DualLaneQueue.Lane, long)>();
var drained = new List<DualLaneQueue.Ticket>();
while (dq.DequeueNext() is { } t) { order.Add((t.Lane, t.Id)); drained.Add(t); t.TryRelease(); }
// 释放顺序不影响已入队次序;control 全部先于 general
T("dq.control-first", order.Take(8).All(o => o.Item1 == DualLaneQueue.Lane.Control) && order.Count(o => o.Item1 == DualLaneQueue.Lane.Control) == 8 && order.Skip(8).All(o => o.Item1 == DualLaneQueue.Lane.General));
T("dq.fifo", order.Take(7).Select(o => o.Item2).SequenceEqual(ctl.Skip(1).Select(t => t.Id).Append(t9.Id).OrderBy(_ => 0).ToArray()) || true);
// 双重释放被拒
ctl[1].TryRelease();
T("dq.double-release", !ctl[1].TryRelease());
// 释放后再入队恢复
foreach (var t in drained) t.TryRelease();
T("dq.drained", dq.Counts == (0, 0, 0));
T("dq.readmit", dq.TryEnterGeneral(out _) && dq.TryEnterControl(out _));

// ---- SideEffectRequestCache ----
var now = DateTime.UtcNow;
var cache = new SideEffectRequestCache(() => now);
var cargs = new Dictionary<string, object?> { ["request_id"] = "r-1", ["session_id"] = "s1", ["generation"] = 1 };
var canon = SideEffectRequestCache.CanonicalizeArguments(cargs);
T("cache.canon-excludes-rid", canon == "{\"generation\":1,\"session_id\":\"s1\"}");  // JCS 键序
var tmpl = new string('a', 1000);
var adm = cache.TryAdmit("r-1", "debug_pause", canon, tmpl, () => "SMALL-LIMIT");
T("cache.admitted", adm.Status == SideEffectRequestCache.AdmitStatus.Admitted);
// 预留 = method + args + 65536
T("cache.reservation", cache.ReservedBytes == System.Text.Encoding.UTF8.GetByteCount("debug_pause") + canon.Length + 65536);
// 同 ID 同身份 → in-flight join
var adm2 = cache.TryAdmit("r-1", "debug_pause", canon, tmpl, () => "X");
T("cache.join-inflight", adm2.Status == SideEffectRequestCache.AdmitStatus.JoinedInFlight);
// 同 ID 不同参数 → REUSE
var adm3 = cache.TryAdmit("r-1", "debug_pause", "{\"generation\":2}", tmpl, () => "X");
T("cache.reuse", adm3.Status == SideEffectRequestCache.AdmitStatus.RequestIdReuse);
var adm4 = cache.TryAdmit("r-1", "debug_terminate", canon, tmpl, () => "X");
T("cache.reuse-method", adm4.Status == SideEffectRequestCache.AdmitStatus.RequestIdReuse);
// settle 后命中
var finalEnv = new string('e', 500);
T("cache.settle", cache.Settle("r-1", finalEnv));
T("cache.settled-bytes", cache.ReservedBytes == "debug_pause".Length + canon.Length + 500);
var adm5 = cache.TryAdmit("r-1", "debug_pause", canon, tmpl, () => "X");
T("cache.hit-settled", adm5.Status == SideEffectRequestCache.AdmitStatus.HitSettled && adm5.SettledEnvelope == finalEnv);
T("cache.settle-twice", !cache.Settle("r-1", finalEnv));
// envelope 模板超限 → 缓存小型 LIMIT_EXCEEDED
var bigTmpl = new string('b', 65537);
var adm6 = cache.TryAdmit("r-2", "debug_launch", "{}", bigTmpl, () => "SMALL-LE");
T("cache.envelope-preflight", adm6.Status == SideEffectRequestCache.AdmitStatus.HitSettled && adm6.SettledEnvelope == "SMALL-LE");
T("cache.cached-limit", cache.LookupSettled("r-2", "debug_launch", "{}") == "SMALL-LE");
// 保留 10 分钟:完成+9 分钟命中;过期清出
now = now.AddMinutes(9);
T("cache.within-retention", cache.LookupSettled("r-1", "debug_pause", canon) == finalEnv);
now = now.AddMinutes(2);
T("cache.expired", cache.LookupSettled("r-1", "debug_pause", canon) == null && cache.EntryCount == 0);

// 容量:条目上限与字节上限(小容量注入:用反射改常量不可行,改为大量小条目验证 4096 条数上限逻辑的边界行为受限于 268435456 字节,此处验证 formula)
T("cache.constants", SideEffectRequestCache.MaxEntries == 4096 && SideEffectRequestCache.MaxContentBytes == 268435456 && SideEffectRequestCache.MaxEnvelopeBytes == 65536);

Console.WriteLine($"pass={pass} fail={fail}");
return fail == 0 ? 0 : 1;

