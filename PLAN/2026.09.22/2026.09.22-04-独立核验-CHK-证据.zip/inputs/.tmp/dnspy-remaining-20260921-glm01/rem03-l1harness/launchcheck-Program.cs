using System;
using System.Collections.Generic;
using System.Linq;
using dnSpy.Extension.MCP.Debugger;

int pass = 0, fail = 0;
void T(string label, bool cond) { if (cond) pass++; else { fail++; Console.WriteLine("FAIL " + label); } }

string E(string s) => WindowsArgumentEncoder.EncodeElement(s);
// ---- 固定向量(§3.5 规则手推) ----
Console.WriteLine("DBG1=[" + E("abc\\ ") + "]");
Console.WriteLine("DBG2=[" + WindowsArgumentEncoder.EncodeCommandLine(new[] { "-t", "a b" }) + "]");
T("enc.empty", E("") == "\"\"");
T("enc.plain", E("abc") == "abc");
T("enc.space", E("a b") == "\"a b\"");
T("enc.tab", E("a\tb") == "\"a\tb\"");
T("enc.quote", E("a\"b") == "\"a\\\"b\"");
T("enc.only-quote", E("\"") == "\"\\\"\"");
T("enc.bare-backslash", E("abc\\") == "abc\\");
T("enc.trailing-bs-quoted", E("a b\\") == "\"a b\\\\\"");
T("enc.bs-run-before-quote", E("a\\\"b") == "\"a\\\\\\\"b\"");   // n=1 → 3 反斜杠 + 引号
T("enc.bs2-before-quote", E("a\\\\\"b") == "\"a\\\\\\\\\\\"b\""); // n=2 → 5 反斜杠 + 引号
T("enc.join", WindowsArgumentEncoder.EncodeCommandLine(new[] { "a b", "", "c" }) == "\"a b\" \"\" c");

// ---- 映射器 ----
var plan = LaunchPlanner.Plan(new LaunchPlanner.LaunchRequest {
	TargetPath = "C:\\s\\Sample.exe", LaunchMode = "net48-exe",
	TargetArgv = new[] { "-t", "a b" }, BreakKind = "entry",
}, out var e1);
if (plan == null) Console.WriteLine("PLAN=NULL e1=" + e1);
else Console.WriteLine("PLAN fn=[" + plan.Filename + "] cl=[" + plan.CommandLine + "] wd=[" + plan.WorkingDirectory + "] host=" + plan.UseHost + " bk=" + plan.UpstreamBreakKind + " fam=" + plan.RuntimeFamily);
T("map.net48", plan != null && plan.Filename == "C:\\s\\Sample.exe" && plan.CommandLine == "-t \"a b\""
	&& plan.WorkingDirectory == "C:\\s" && !plan.UseHost && plan.UpstreamBreakKind == dnSpy.Contracts.Debugger.PredefinedBreakKinds.EntryPoint
	&& plan.RuntimeFamily == "net48");

// 性质测试输出:Python 参考解析器(CommandLineToArgvW 规则)往返
var rng = new Random(20260827);
var alphabet = new[] { 'a', ' ', '"', '\\', 'b', '\t' };
for (int i = 0; i < 300; i++) {
	int len = rng.Next(0, 12);
	var arg = new string(Enumerable.Range(0, len).Select(_ => alphabet[rng.Next(alphabet.Length)]).ToArray());
	Console.WriteLine("PROP|" + Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(arg)) + "|" + E(arg));
}

Console.WriteLine($"pass={pass} fail={fail}");
return 0;
