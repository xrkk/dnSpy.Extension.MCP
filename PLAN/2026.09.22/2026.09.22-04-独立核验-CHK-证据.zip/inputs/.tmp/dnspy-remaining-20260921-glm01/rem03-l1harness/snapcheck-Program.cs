using System;
using System.Collections.Generic;
using System.Linq;
using dnSpy.Extension.MCP;

int pass = 0, fail = 0;
void T(string label, bool cond) { if (cond) pass++; else { fail++; Console.WriteLine("FAIL " + label); } }
void Tsnap(string label, McpSettingsSnapshot s) { if (s != null) pass++; else { fail++; Console.WriteLine("FAIL " + label); } }
void Terr(string label, string expectedSub, string? err) {
    if (err != null && err.Contains(expectedSub)) pass++;
    else { fail++; Console.WriteLine($"FAIL {label}: err={err}"); }
}

// 1) SafeDefaults 逐字段
var d = McpSettingsSnapshot.SafeDefaults();
T("default.schema", d.SchemaVersion == "dnspy.mcp.settings.v1");
// 2026-09-21 适配: SafeDefaults 现为 remote-host-only 姿态(Host=192.168.204.149, Port=15378,
// 单一 TrustedHostOnlyPeerCidr, RemoteHostOnlyAcknowledged=true; EnableServer=false 时惰性)
T("default.fields", !d.EnableServer && d.Host == "192.168.204.149" && d.Port == 15378 && !d.DebugToolsEnabled
  && !d.DedicatedDebugInstanceAcknowledged && d.AllowedSampleRoot == "" && d.RemoteAllowedCidrs.Count == 1
  && d.RemoteAllowedCidrs[0] == "192.168.204.1/32"
  && d.RemoteTokenVerifier == null && d.RemoteHostOnlyAcknowledged);
T("default.artifact", d.ArtifactRoot.Replace('\\','/').EndsWith("dnspy-mcp-artifacts", StringComparison.Ordinal));

// 2) 验证矩阵
var ok = McpSettingsSnapshot.TryCreate(true, "192.168.204.149", 15100, false, false, "", "C:\\t\\dnspy-mcp",
    new[] { "192.168.204.0/24", "10.0.0.0/8" }.OrderBy(s => s, StringComparer.Ordinal).ToArray(),
    new string('a', 64), true, out var e1);
Tsnap("remote.valid", ok);
// 修正排序: "10.0.0.0/8" < "192.168..." ordinal — 上面顺序错误应被拒绝
var badOrder = McpSettingsSnapshot.TryCreate(true, "192.168.204.149", 15100, false, false, "", "C:\\t",
    new[] { "192.168.204.0/24", "10.0.0.0/8" }, new string('a', 64), true, out var eOrder);
T("remote.unsorted-rejected", badOrder == null && eOrder.Contains("ordinal-sorted"));
Terr("port.0", "1..65535", McpSettingsSnapshot.TryValidate(0, "localhost", new string[0], null, false, out _));
Terr("port.65536", "1..65535", McpSettingsSnapshot.TryValidate(65536, "localhost", new string[0], null, false, out _));
Terr("host.name", "IP literal", McpSettingsSnapshot.TryValidate(3000, "example.com", new string[0], null, false, out _));
Terr("host.wildcard", "IP literal", McpSettingsSnapshot.TryValidate(3000, "+", new string[0], null, false, out _));
Terr("cidr.mapped", "IPv4-mapped", McpSettingsSnapshot.TryValidate(3000, "192.168.204.149", new[] { "::ffff:192.168.0.0/120" }, new string('a', 64), true, out _));
Terr("cidr.hostbits", "host bits", McpSettingsSnapshot.TryValidate(3000, "192.168.204.149", new[] { "192.168.204.1/24" }, new string('a', 64), true, out _));
Terr("cidr.leadingzero", "canonical text", McpSettingsSnapshot.TryValidate(3000, "192.168.204.149", new[] { "192.168.204.000/24" }, new string('a', 64), true, out _));
Terr("cidr.upper-v6", "canonical text", McpSettingsSnapshot.TryValidate(3000, "fd00::1", new[] { "FD00::/8" }, new string('a', 64), true, out _));
Terr("cidr.dup", "duplicates", McpSettingsSnapshot.TryValidate(3000, "192.168.204.149", new[] { "10.0.0.0/8", "10.0.0.0/8" }, new string('a', 64), true, out _));
Terr("cidr.17", "At most 16", McpSettingsSnapshot.TryValidate(3000, "192.168.204.149",
    Enumerable.Range(1, 17).Select(i => $"10.{i}.0.0/16").ToArray(), new string('a', 64), true, out _));
Terr("verifier.upper", "64 lowercase", McpSettingsSnapshot.TryValidate(3000, "192.168.204.149", new[] { "10.0.0.0/8" }, new string('A', 64), true, out _));
Terr("remote.noack", "Acknowledged must be true", McpSettingsSnapshot.TryValidate(3000, "192.168.204.149", new[] { "10.0.0.0/8" }, new string('a', 64), false, out _));
Terr("remote.nocidr", "must not be empty", McpSettingsSnapshot.TryValidate(3000, "192.168.204.149", new string[0], new string('a', 64), true, out _));
Terr("loopback.cidr", "must be empty", McpSettingsSnapshot.TryValidate(3000, "localhost", new[] { "10.0.0.0/8" }, null, false, out _));
T("v6.valid", McpSettingsSnapshot.TryValidate(3000, "fd00::1", new[] { "fd00::/8" }, new string('a', 64), true, out _) == null);

// 3) 持久化解析
var snap = McpSettingsSnapshot.TryCreate(true, "192.168.204.149", 15100, false, false, "", "C:\\t\\dnspy-mcp",
    new[] { "10.0.0.0/8", "192.168.204.0/24" }, new string('a', 64), true, out _);
var canonical = snap.ToCanonicalJson();
T("parse.roundtrip", McpSettingsPersistence.TryParseEffective(canonical, out _) != null);
T("parse.noncanon-keyorder", McpSettingsPersistence.TryParseEffective(
    "{\"AllowedSampleRoot\":\"\",\"ArtifactRoot\":\"C:\\\\t\\\\dnspy-mcp\",\"DedicatedDebugInstanceAcknowledged\":false,\"DebugToolsEnabled\":false,\"EnableServer\":true,\"Host\":\"192.168.204.149\",\"Port\":15100,\"RemoteAllowedCidrs\":[\"10.0.0.0/8\",\"192.168.204.0/24\"],\"RemoteHostOnlyAcknowledged\":true,\"RemoteTokenVerifier\":\"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\",\"SchemaVersion\":\"dnspy.mcp.settings.v1\", \"X\":1}", out _) == null);
T("parse.noncanon-space", McpSettingsPersistence.TryParseEffective(canonical.Replace(":", ": "), out _) == null);
T("parse.missing-field", McpSettingsPersistence.TryParseEffective(canonical.Replace("\"Port\":15100,", ""), out _) == null);
T("parse.wrong-type", McpSettingsPersistence.TryParseEffective(canonical.Replace("\"Port\":15100", "\"Port\":\"x\""), out _) == null);

// 4) 启动恢复矩阵
var r1 = McpSettingsPersistence.Recover(null, null, null);
T("rec.both-missing-fresh", r1.Snapshot.Port == 15378 && r1.Warning == null && !r1.TryClearPending);
var r2 = McpSettingsPersistence.Recover(null, null, (true, "localhost", 3000));
T("rec.legacy-valid", r2.Snapshot.EnableServer && r2.Warning == null);
var r3 = McpSettingsPersistence.Recover(null, null, (true, "localhost", 0));
T("rec.legacy-invalid", !r3.Snapshot.EnableServer && r3.Warning == McpSettingsPersistence.InvalidStoredWarning);
var r4 = McpSettingsPersistence.Recover(canonical, canonical, null);
T("rec.pending-eq-committed", r4.Snapshot.Port == 15100 && r4.TryClearPending && r4.Warning == null);
var r5 = McpSettingsPersistence.Recover(canonical, canonical.Replace("15100", "15101"), null);
T("rec.pending-differs", r5.Snapshot.Port == 15100 && r5.TryClearPending);
var r6 = McpSettingsPersistence.Recover(canonical.Replace("15100", "70000"), canonical, null);
T("rec.committed-invalid", r6.Snapshot.Port == 15378 && r6.TryClearPending && r6.Warning == McpSettingsPersistence.InvalidStoredWarning);
var r7 = McpSettingsPersistence.Recover(null, canonical, null);
T("rec.orphan-pending", r7.Snapshot.Port == 15378 && r7.TryClearPending && r7.Warning == null);
var r8 = McpSettingsPersistence.Recover(canonical, null, null);
T("rec.committed-only", r8.Snapshot.Port == 15100 && !r8.TryClearPending && r8.Warning == null);

// 5) 输出 canonical 供 Python JCS 对比
Console.WriteLine("CANONICAL:" + canonical);
Console.WriteLine("DEFAULT_CANONICAL:" + d.ToCanonicalJson());
Console.WriteLine($"pass={pass} fail={fail}");
return fail == 0 ? 0 : 1;
