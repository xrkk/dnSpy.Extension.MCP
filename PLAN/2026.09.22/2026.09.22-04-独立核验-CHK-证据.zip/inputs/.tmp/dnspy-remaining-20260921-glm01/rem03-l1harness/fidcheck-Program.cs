using System;
using System.Collections.Generic;
using System.Linq;
using dnSpy.Extension.MCP;
using dnSpy.Extension.MCP.Debugger;
using dnSpy.Extension.MCP.Transport;

int pass = 0, fail = 0;
void T(string label, bool cond) { if (cond) pass++; else { fail++; Console.WriteLine("FAIL " + label); } }

// ---- 三个禁用 stub(经 provider 与 registry 双路径) ----
// 2026-09-21 适配: DebugToolProvider 构造增至4参(sessionService+executionGate), ExecuteTool
// 改为 internal 接口实现(McpCallContext internal)。经反射调用当前合法私有入口, 断言不变。
var settings = new NoLogSettings();
var gate = new DebugGateService(null, null);
var sessionSvc = new DebugSessionService(null, null, null, null, gate, null, settings, null, null);
var provider = new DebugToolProvider(settings, gate, sessionSvc, null);
System.Reflection.MethodInfo exec = typeof(DebugToolProvider).GetMethods(
    System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic)
    .First(m => m.Name == "ExecuteTool" && m.GetParameters().Length == 3);
CallToolResult Exec(string name, Dictionary<string, object> args) =>
    (CallToolResult)exec.Invoke(provider, new object[] { name, args, null });
var tools = provider.GetTools();
T("stub.not-advertised", tools.All(t => t.Name != "debug_attach" && t.Name != "debug_detach"
	&& t.Name != "debug_list_attachable_processes") && tools.Count == 1);
string ExpectedDisabledJson = "{\"schema_version\":\"dnspy.debug.v1\",\"ok\":false,\"debug_context\":{\"generation\":0,\"pause_epoch\":0,\"event_cursor\":0,\"state\":\"idle\"},\"error\":{\"code\":\"CAPABILITY_UNAVAILABLE\",\"message\":\"The requested capability is unavailable.\",\"recovery\":\"choose_supported_workflow\",\"current_state\":\"idle\",\"required_states\":[]},\"warnings\":[],\"untrusted_sample_data\":false}";
foreach (var name in new[] { "debug_list_attachable_processes", "debug_attach", "debug_detach" }) {
	var result = Exec(name, new Dictionary<string, object>());
	T($"stub.{name}", result != null && result.IsError && result.Content[0].Text == ExpectedDisabledJson);
}
var resultArgs = Exec("debug_attach", new Dictionary<string, object> { ["pid"] = 4242 });
T("stub.args-ignored", resultArgs != null && resultArgs.Content[0].Text == ExpectedDisabledJson);
// 未知工具仍为 null(registry 报 Unknown tool)
T("stub.unknown-still-null", Exec("debug_evaluate", null) == null);

// 与冻结 fixture 字节级一致(fixed-capability-unavailable@2025-06-18)
var fixture = System.Text.Json.JsonDocument.Parse(System.IO.File.ReadAllText(
	"/home/adminn/projects/dnSpy.Extension.MCP/tests/debug/contracts/fixtures/debug_attach@2025-06-18.json"));
string fixtureText = null;
foreach (var c in fixture.RootElement.GetProperty("cases").EnumerateArray())
	if (c.GetProperty("id").GetString().Contains("fixed-capability-unavailable"))
		fixtureText = c.GetProperty("expected_response").GetProperty("result").GetProperty("content")[0].GetProperty("text").GetString();
if (fixtureText != ExpectedDisabledJson) { Console.WriteLine("FIXTURE=" + fixtureText); Console.WriteLine("IMPL   =" + ExpectedDisabledJson); }
T("stub.fixture-byte-equal", fixtureText == ExpectedDisabledJson);

// ---- FileIdentity 模型 ----
var file = new FileIdentityDto { Role = "target", ObjectKind = "file", FinalPath = "C:\\samples\\A.exe",
	VolumeSerial = "0x" + new string('a', 16), FileId = new string('b', 32), Sha256 = new string('c', 64) };
T("fid.valid-file", FileIdentityDto.Validate(file) == null);
var dir = new FileIdentityDto { Role = "working_directory", ObjectKind = "directory", FinalPath = "C:\\samples",
	VolumeSerial = "0x" + new string('a', 16), FileId = new string('b', 32) };
T("fid.valid-dir", FileIdentityDto.Validate(dir) == null);
T("fid.file-no-sha", FileIdentityDto.Validate(new FileIdentityDto { Role = "target", ObjectKind = "file",
	FinalPath = "C:\\a", VolumeSerial = "0x" + new string('a', 16), FileId = new string('b', 32) }) != null);
T("fid.dir-with-sha", FileIdentityDto.Validate(new FileIdentityDto { Role = "working_directory", ObjectKind = "directory",
	FinalPath = "C:\\a", VolumeSerial = "0x" + new string('a', 16), FileId = new string('b', 32), Sha256 = new string('c', 64) }) != null);
T("fid.upper-hex-rejected", FileIdentityDto.Validate(new FileIdentityDto { Role = "target", ObjectKind = "file",
	FinalPath = "C:\\a", VolumeSerial = "0X" + new string('A', 16), FileId = new string('B', 32), Sha256 = new string('c', 64) }) != null);
T("fid.bad-role", FileIdentityDto.Validate(new FileIdentityDto { Role = "other", ObjectKind = "file",
	FinalPath = "C:\\a", VolumeSerial = "0x" + new string('a', 16), FileId = new string('b', 32), Sha256 = new string('c', 64) }) != null);

// ---- Windows 路径关系 ----
T("path.eq-case", WindowsPathRelation.EqualPath("C:\\Samples\\A", "c:/samples/a"));
T("path.contains", WindowsPathRelation.Contains("C:\\samples", "C:\\samples\\sub\\x.dll"));
T("path.no-partial", !WindowsPathRelation.Contains("C:\\sample", "C:\\samples\\x.dll"));
T("path.no-equal-contains", !WindowsPathRelation.Contains("C:\\a", "C:\\a"));
T("path.drive-root", WindowsPathRelation.Contains("C:", "C:\\x"));
T("path.roots-disjoint", WindowsPathRelation.RootsAreDisjoint(new[] { "C:\\samples", "C:\\temp\\dnspy-mcp", "D:\\dnspy" }));
T("path.roots-overlap", !WindowsPathRelation.RootsAreDisjoint(new[] { "C:\\samples", "C:\\samples\\sub" }));
T("path.roots-equal", !WindowsPathRelation.RootsAreDisjoint(new[] { "C:\\Samples", "c:\\samples" }));

// ---- LeaseBook ----
var book = new FileIdentityLeaseBook();
T("lease.ok", book.Lease(file));
T("lease.dup-role", !book.Lease(new FileIdentityDto { Role = "target", ObjectKind = "file", FinalPath = "C:\\other.exe",
	VolumeSerial = "0x" + new string('a', 16), FileId = new string('b', 32), Sha256 = new string('c', 64) }));
var observedSame = new FileIdentityDto { Role = "target", ObjectKind = "file", FinalPath = "C:\\SAMPLES\\A.exe",
	VolumeSerial = "0x" + new string('a', 16), FileId = new string('b', 32), Sha256 = new string('c', 64) };
T("lease.match-case-path", book.Observe(observedSame) == FileIdentityLeaseBook.ObserveResult.Match);
var observedDifferentId = new FileIdentityDto { Role = "target", ObjectKind = "file", FinalPath = "C:\\samples\\A.exe",
	VolumeSerial = "0x" + new string('a', 16), FileId = new string('d', 32), Sha256 = new string('c', 64) };
T("lease.mismatch-id", book.Observe(observedDifferentId) == FileIdentityLeaseBook.ObserveResult.Mismatch);
var observedDifferentPath = new FileIdentityDto { Role = "target", ObjectKind = "file", FinalPath = "C:\\samples\\replaced.exe",
	VolumeSerial = "0x" + new string('a', 16), FileId = new string('b', 32), Sha256 = new string('c', 64) };
T("lease.mismatch-path", book.Observe(observedDifferentPath) == FileIdentityLeaseBook.ObserveResult.Mismatch);
T("lease.no-lease", book.Observe(dir) == FileIdentityLeaseBook.ObserveResult.NoLease);

Console.WriteLine($"pass={pass} fail={fail}");
return fail == 0 ? 0 : 1;

class NoLogSettings : McpSettings {
	public override void Log(string message) { }
}
