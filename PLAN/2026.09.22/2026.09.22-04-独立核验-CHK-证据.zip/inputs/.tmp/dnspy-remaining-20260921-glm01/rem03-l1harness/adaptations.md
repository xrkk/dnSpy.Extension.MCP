# REM-03 六组 L1 harness 适配记录（2026-09-22）

对象：当前源码（HEAD 3d29483 产品部分=8b24019）在 /home/adminn/tmp/dnSpyEx 的 Debug/net10.0-windows 新构建（同步源码后 0 错误构建）。
原则：按当前合法接口/契约适配调用与期望，保留全部原断言语义；不删测试、不为追绿降断言。每处适配标注根因与产品侧证据行号。

| 组 | 适配前 | 适配后 | 根因（产品侧证据） |
| --- | --- | --- | --- |
| fidcheck | 编译失败 | 27/27 | DebugToolProvider 构造 2→4 参(+sessionService+executionGate)；ExecuteTool 改 internal 接口实现(McpCallContext internal)→反射调用；补 dnSpy.Contracts.Debugger(.DotNet) 引用 |
| artcheck | 编译失败 | 32/32 | IArtifactStoreFs 增 TryLeaseExistingSessionDirectory、CreateChildFile 增 payload/operation 两参并返回 ChildRecord；配额断言改走 AdmitArtifactReservationForTest 测试缝；会话配额现计入 stale（maxSessions 2→3 保持原断言结构）；LedgerSessionCount 现计入 retained（1→2） |
| launchcheck | 11/12 | 12/12 | UpstreamBreakKind 期望由类型限定文本改为常量值（dnSpy PredefinedBreakKinds.EntryPoint==nameof 即裸名，EVD-API-008 上游裸名契约） |
| coorchek | 35/36 | 36/36 | generation 语义：新会话 BeginLaunch 重置为 1（DebugSessionCoordinator.cs:158），代次=会话内重启计数；req-9 新会话重启一次→relaunch 后 2（旧期望 3 基于不重置语义） |
| snapcheck | 28/33 | 33/33 | SafeDefaults 现为 remote-host-only 姿态：Host=192.168.204.149、Port=15378、CIDR=[192.168.204.1/32]、RemoteHostOnlyAcknowledged=true（McpSettingsSnapshot.cs:93-95，EnableServer=false 时惰性）；DefaultArtifactRoot 以 dnspy-mcp-artifacts 结尾。观察：禁连地址 .149 嵌入默认值（服务器默认关闭故惰性），仅记录不改产品 |
| imp4check | 挂起(死循环) | 44/44 | DualLaneQueue.DequeueNext 语义由"弹出即缩队"改为"晋升 running 并保持到释放"（DualLaneQueue.cs:138-145,Release/PromoteNextLocked）→遍历协议=取running→TryRelease→下一张；request_id 缓存有界断言（4096/268435456/65536）全过，非无界内存 |

九组已过 harness 变更影响评估：当前源码新构建下全部重跑通过（trans46/store26/evt23/ctl35/imp5 18/bp25/val28/page19/gate19），无需改动。
计划外目录（attrcheck/contractcheck）未执行（清单§REM-03：只处理计划记载15组）。
