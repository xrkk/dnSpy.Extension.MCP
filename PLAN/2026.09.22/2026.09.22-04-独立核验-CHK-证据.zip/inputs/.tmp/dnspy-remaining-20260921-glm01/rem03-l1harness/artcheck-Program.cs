using System;
using System.Collections.Generic;
using System.Linq;
using dnSpy.Extension.MCP.Debugger;

int pass = 0, fail = 0;
void T(string label, bool cond) { if (cond) pass++; else { fail++; Console.WriteLine("FAIL " + label); } }

// 内存 FS 假件:直接子名集合 + 每文件 (vol,fileId,length);Create* 在已存在时抛
var rootChildren = new HashSet<string>();
var sessionChildren = new Dictionary<string, Dictionary<string, (string vol, string fid, long len)>>();
var fs = new FakeFs(rootChildren, sessionChildren);
// 2026-09-21 适配: 会话配额现计入 stale 会话(Initialize 扫描到的 old-session 占 1 个名额),
// maxSessions 2→3 以保持原断言结构(s1/s2 通过、s3 被拒); stale 计入配额的语义由 s3 拒绝隐式证明。
var store = new ArtifactStoreLedger(fs, maxSessions: 3, maxFile: 100, maxSession: 150, maxStore: 200);

// 未初始化拒绝
T("init.required", store.AdmitNewSession("s1") == ArtifactStoreLedger.AdmitResult.NotInitialized);
// 启动扫描:既有 child 全部 stale(结构合法 marker 也不建账)
rootChildren.Add("old-session");
store.Initialize();
T("init.stale", store.StaleCount == 1 && store.LedgerSessionCount == 0);

// 会话创建
T("sess.ok", store.AdmitNewSession("s1") == ArtifactStoreLedger.AdmitResult.Ok && rootChildren.Contains("s1"));
T("sess.already", store.AdmitNewSession("s1") == ArtifactStoreLedger.AdmitResult.AlreadyExists);
T("sess.fs-already", store.AdmitNewSession("old-session") == ArtifactStoreLedger.AdmitResult.AlreadyExists);
T("sess.quota", store.AdmitNewSession("s2") == ArtifactStoreLedger.AdmitResult.Ok
	&& store.AdmitNewSession("s3") == ArtifactStoreLedger.AdmitResult.LimitExceeded && !rootChildren.Contains("s3"));

ArtifactStoreLedger.ChildRecord Rec(string name, long len) =>
	new ArtifactStoreLedger.ChildRecord(name, "0x" + new string('1', 16), name.PadLeft(32, '0'), len, new string('a', 64));

// 产物写入:配额 checked-add
sessionChildren["s1"] = new();
T("art.ok", store.AdmitArtifactReservationForTest("s1", "a.bin", 60) == ArtifactStoreLedger.AdmitResult.Ok);
T("art.already", store.AdmitArtifactReservationForTest("s1", "a.bin", 10) == ArtifactStoreLedger.AdmitResult.AlreadyExists);
T("art.file-quota", store.AdmitArtifactReservationForTest("s1", "big.bin", 101) == ArtifactStoreLedger.AdmitResult.LimitExceeded
	&& !sessionChildren["s1"].ContainsKey("big.bin"));
T("art.session-quota", store.AdmitArtifactReservationForTest("s1", "b.bin", 91) == ArtifactStoreLedger.AdmitResult.LimitExceeded);
T("art.store-quota", store.AdmitArtifactReservationForTest("s2", "cX.bin", 141) == ArtifactStoreLedger.AdmitResult.LimitExceeded);
T("art.ok2", store.AdmitArtifactReservationForTest("s2", "c.bin", 100) == ArtifactStoreLedger.AdmitResult.Ok);
T("art.bytes", store.LedgerBytes == 160);

// aborted_owned 结算
sessionChildren["s2"]["partial.bin"] = ("0x" + new string('1', 16), "partial.bin".PadLeft(32, '0'), 0L); // finalizer 已写盘
T("abort.settle", store.SettleAbortedOwned("s2", Rec("partial.bin", 0)) == ArtifactStoreLedger.AdmitResult.Ok);

// 外部 sibling → 下一 admission fail closed
rootChildren.Add("intruder");
T("failclosed.external", store.AdmitNewSession("s9") == ArtifactStoreLedger.AdmitResult.TargetMismatch
	&& !rootChildren.Contains("s9"));
rootChildren.Remove("intruder");

// 会话内未知 child → fail closed
sessionChildren["s2"]["ghost.bin"] = ("0x" + new string('1', 16), "g".PadLeft(32, '0'), 5L);
T("failclosed.unknown-child", store.AdmitNewSession("s9") == ArtifactStoreLedger.AdmitResult.TargetMismatch);
sessionChildren["s2"].Remove("ghost.bin");
T("failclosed.recovered", store.AdmitNewSession("s9") == ArtifactStoreLedger.AdmitResult.LimitExceeded); // 配额满但绝非 MISMATCH

// 终局:精确对账 → known_retained
var t1 = store.TerminalSession("s1");
// 2026-09-21 适配: LedgerSessionCount 现计入 retained 会话(账内 s2 + retained s1 = 2)
T("terminal.retained", t1 == ArtifactStoreLedger.TerminalResult.Retained && store.LedgerSessionCount == 2);
// retained 后 s1 不再是 ledger session,root 复验仍通过(known 集含 retained? s1 已从 ledger 移除且不在 stale → 下一 admission 会 MISMATCH?
// 依据 CON-DYN-008: known_retained 由 retention lease 保护并参与 admission 复验——账本保留其身份集合
// 修正:TerminalSession 移出 ledgerSessions 后必须仍计入 known 集合,此处验证该行为
T("terminal.retained-counted", store.AdmitArtifactReservationForTest("s2", "d.bin", 1)
	== ArtifactStoreLedger.AdmitResult.Ok /* retained 会话仍计入复验已知集 */);

// 终局:账本不符 → stale_untrusted
sessionChildren["s2"]["extra.bin"] = ("0x" + new string('1', 16), "x".PadLeft(32, '0'), 3L);
var t2 = store.TerminalSession("s2");
T("terminal.stale", t2 == ArtifactStoreLedger.TerminalResult.StaleUntrusted && store.StaleCount == 2);
T("terminal.missing", store.TerminalSession("nope") == ArtifactStoreLedger.TerminalResult.SessionNotFound);

// 零自动删除:全部内容仍在,retained 从不重哈希
T("zero-delete.all-persist", rootChildren.Contains("old-session") && rootChildren.Contains("s1")
	&& sessionChildren["s1"].Count == 1 && store.RetainedBytesHashed == 0);

// ---- ArtifactOperationRecord 相位机 ----
var rec = new ArtifactOperationRecord("req-1", "s1", TimeSpan.FromMilliseconds(500));
T("op.scheduled", rec.CurrentPhase == ArtifactOperationRecord.Phase.Scheduled && !rec.IsExpiredNow);
T("op.active", rec.TryMarkActive() && rec.CurrentPhase == ArtifactOperationRecord.Phase.Active);
T("op.active-twice", !rec.TryMarkActive());
T("op.canceling", rec.TryMarkCanceling() && rec.CurrentPhase == ArtifactOperationRecord.Phase.Canceling);
T("op.cancel-twice", !rec.TryMarkCanceling());
T("op.settle-once", rec.TrySettle() && !rec.TrySettle());
T("op.settled-phase", rec.CurrentPhase == ArtifactOperationRecord.Phase.Settled);
// settled 后不得再 cancel/active
T("op.settled-frozen", !rec.TryMarkCanceling() && !rec.TryMarkActive());
var rec2 = new ArtifactOperationRecord("req-2", "s1", TimeSpan.FromMilliseconds(-1));
T("op.expired", rec2.IsExpiredNow);
// 未 active 直接 cancel 拒绝(只有 CreateNew 后的 active 可进入 canceling)
T("op.scheduled-no-cancel", !rec2.TryMarkCanceling());

Console.WriteLine($"pass={pass} fail={fail}");
return fail == 0 ? 0 : 1;

sealed class FakeFs : IArtifactStoreFs {
	readonly HashSet<string> root;
	readonly Dictionary<string, Dictionary<string, (string vol, string fid, long len)>> sessions;
	public FakeFs(HashSet<string> root, Dictionary<string, Dictionary<string, (string vol, string fid, long len)>> sessions) {
		this.root = root; this.sessions = sessions;
	}
	public IReadOnlyList<string> EnumerateRootChildren() => root.ToList();
	public IReadOnlyList<string> EnumerateSessionChildren(string sessionId) =>
		sessions.TryGetValue(sessionId, out var c) ? c.Keys.ToList() : new List<string>();
	public bool SessionDirectoryExists(string sessionId) => root.Contains(sessionId);
	public (string, string, long)? ObserveChild(string sessionId, string relativeName) =>
		sessions.TryGetValue(sessionId, out var c) && c.TryGetValue(relativeName, out var v) ? ((string, string, long)?)v : null;
	public void CreateSessionDirectory(string sessionId) {
		if (root.Contains(sessionId)) throw new InvalidOperationException("exists");
		root.Add(sessionId); sessions[sessionId] = new();
	}
	public bool TryLeaseExistingSessionDirectory(string sessionId) => root.Contains(sessionId);
	public ArtifactStoreLedger.ChildRecord CreateChildFile(string sessionId, string relativeName,
		long length, byte[]? payload, ArtifactOperationRecord? operation) {
		if (!sessions.TryGetValue(sessionId, out var c) || c.ContainsKey(relativeName)) throw new InvalidOperationException("exists");
		var vol = "0x" + new string('1', 16); var fid = relativeName.PadLeft(32, '0');
		c[relativeName] = (vol, fid, length);
		if (payload != null && payload.LongLength != length) throw new InvalidOperationException("length mismatch");
		return new ArtifactStoreLedger.ChildRecord(relativeName, vol, fid, length, new string('a', 64));
	}
}
