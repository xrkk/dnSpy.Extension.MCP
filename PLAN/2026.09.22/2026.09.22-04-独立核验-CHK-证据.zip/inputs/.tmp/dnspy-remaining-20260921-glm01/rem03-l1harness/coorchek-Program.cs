using System;
using System.Collections.Generic;
using System.Linq;
using dnSpy.Extension.MCP.Debugger;

int pass = 0, fail = 0;
void T(string label, bool cond) { if (cond) pass++; else { fail++; Console.WriteLine("FAIL " + label); } }
var now = DateTime.UtcNow;
var coord = new DebugSessionCoordinator(
	newSessionId: () => "sess-1",
	utcNow: () => "2026-08-27T10:00:00.000Z",
	wallClock: () => now);

// ---- 生命周期:launch → starting → running ----
T("lc.begin", coord.BeginLaunch("req-1", "net48-exe", "net48", "x64"));
T("lc.state-starting", coord.State == "starting" && coord.ActiveSessionId == "sess-1" && coord.Generation == 1);
var ev1 = coord.ReadEvents("sess-1", 0, 100, null);
T("lc.evt-session-start", ev1 != null && ev1.Events.Count == 1 && ev1.Events[0].Contains("\"kind\":\"session_start\"")
	&& ev1.Events[0].Contains("\"launch_mode\":\"net48-exe\""));
T("lc.second-launch-rejected", !coord.BeginLaunch("req-2", "net48-exe", "net48", "x64"));
T("lc.claim-running", coord.MarkLaunchClaimSucceeded(false, null) && coord.State == "running" && coord.PauseEpoch == 0);

// 重复 BeginLaunch 在非 idle 一律拒绝(3.6)
T("lc.busy-reject", !coord.BeginLaunch("req-3", "net48-exe", "net48", "x64"));

// ---- pause 控制准入与权威观察对账 ----
var adm = coord.TryBeginControl(ControlOperation.Pause, "req-4");
T("pause.admitted", adm.Admitted && adm.Record != null && adm.Record.PriorState == "running");
var admDup = coord.TryBeginControl(ControlOperation.Pause, "req-5");
T("pause.second-rejected", !admDup.Admitted); // 同 session 至多一个未 settled 控制记录
coord.MarkControlIssued(adm.Record);
// 权威 paused 观察:issued pause 结算 state_satisfied
var obs = coord.ObservePaused("sess-1", 1, true, new[] { new BreakInfoObservation("break", 0) });
T("pause.obs", obs.Accepted && obs.PrimaryCause == "manual" && obs.SettledPauseRecord);
T("pause.state", coord.State == "paused" && coord.PauseEpoch == 1 && coord.ObservedProcessState == "paused");
// 重复 paused 观察去重:不重复 epoch/事件
var obs2 = coord.ObservePaused("sess-1", 1, true, new[] { new BreakInfoObservation("break", 1) });
T("pause.dedupe", obs2.Accepted && !obs2.SettledPauseRecord && coord.PauseEpoch == 1);
// 旧 generation 观察被拒绝
var obs3 = coord.ObservePaused("sess-1", 0, true, new[] { new BreakInfoObservation("break", 0) });
T("pause.old-gen-rejected", !obs3.Accepted && coord.State == "paused");

// 事件顺序:session_start, paused(EVT-010), 无重复
var evs = coord.ReadEvents("sess-1", 0, 100, null);
T("pause.evt-count", evs.Events.Count == 2 && evs.Events[1].Contains("\"kind\":\"paused\"") && evs.Events[1].Contains("\"reason\":\"manual\""));

// ---- continue:离开 paused 增计数 + EVT-011 ----
T("cont.resume", coord.MarkResumed("manual") && coord.State == "running" && coord.PauseEpoch == 2);
T("cont.evt", coord.ReadEvents("sess-1", 2, 100, null).Events[0].Contains("\"kind\":\"continued\"") && coord.ReadEvents("sess-1", 2, 100, null).Events[0].Contains("\"reason\":\"manual\""));

// ---- 控制失败:scheduled 恢复 prior_state;issued 进 ControlFault ----
var t1 = coord.TryBeginControl(ControlOperation.Pause, "req-6");
T("cf.admitted", t1.Admitted);
coord.SettleControlFailure(t1.Record, "TIMEOUT"); // scheduled 阶段
T("cf.scheduled-restore", coord.State == "running" && coord.Fault == DebugSessionCoordinator.FaultKind.None);
var t2 = coord.TryBeginControl(ControlOperation.Pause, "req-7");
coord.MarkControlIssued(t2.Record);
coord.SettleControlFailure(t2.Record, "INTERNAL_ERROR"); // issued 阶段
T("cf.issued-faulted", coord.State == "faulted" && coord.Fault == DebugSessionCoordinator.FaultKind.ControlFault);
// 重复结算不产生第二个 EVT-021
int evtBefore = coord.ReadEvents("sess-1", 0, 100, null).Events.Count;
T("cf.settle-twice", !coord.SettleControlFailure(t2.Record, "TIMEOUT") && coord.ReadEvents("sess-1", 0, 100, null).Events.Count == evtBefore);
// ownership_lost faulted 下 terminate 仍拒绝(Y* 仅 ControlFault)
var t3 = coord.TryBeginControl(ControlOperation.Terminate, "req-8");
T("cf.controlfault-terminate-allowed", t3.Admitted && coord.State == "stopping");

// ---- 移除观察:terminate 结算成功 + session_end ----
var rem = coord.ObserveProcessRemoved("sess-1", 1, true, 0);
T("rm.settled-terminate", rem.Accepted && rem.Outcome == "settled-terminate");
T("rm.idle", coord.State == "idle" && coord.ActiveSessionId == null && coord.LastSessionId == "sess-1");
var tevs = coord.ReadEvents("sess-1", 0, 100, null);
T("rm.evt-order", tevs != null && tevs.Events[tevs.Events.Count - 1].Contains("\"kind\":\"session_end\"")
	&& tevs.Events[tevs.Events.Count - 1].Contains("\"reason\":\"terminated\"")
	&& tevs.Events[tevs.Events.Count - 2].Contains("\"kind\":\"process_exited\""));

// 终局保留窗口:10 分钟内可读,过期 NOT_FOUND
now = now.AddMinutes(9);
T("ret.read-within", coord.ReadEvents("sess-1", 0, 100, null) != null);
now = now.AddMinutes(2);
T("ret.expired-null", coord.ReadEvents("sess-1", 0, 100, null) == null);
T("ret.new-session-launchable", coord.BeginLaunch("req-9", "coreclr-apphost", "coreclr", "x64"));

// ---- 重启路径:restarting 保留 session;移除→stopping→relaunch ----
coord.MarkLaunchClaimSucceeded(false, null);
var r1 = coord.TryBeginControl(ControlOperation.Restart, "req-10");
T("rs.admitted", r1.Admitted && coord.State == "restarting" && coord.RestartReservationHeld);
var rrem = coord.ObserveProcessRemoved(coord.ActiveSessionId, coord.Generation, true, 0);
T("rs.pending", rrem.Accepted && rrem.Outcome == "pending-restart" && coord.State == "stopping" && coord.ActiveSessionId != null);
// 2026-09-21 适配: 新会话 BeginLaunch 将 generation 重置为 1(DebugSessionCoordinator.cs:158),
// 代次=会话内重启计数; req-9 新会话重启一次 → relaunch 后 generation=2(旧期望 3 基于不重置语义)
T("rs.relaunch", coord.BeginRestartRelaunch() && coord.State == "starting" && coord.Generation == 2);
coord.MarkLaunchClaimSucceeded(false, null);
T("rs.running", coord.State == "running");

// issued 重启失败 → ControlFault + abandoned + 释放 reservation
var r2 = coord.TryBeginControl(ControlOperation.Restart, "req-11");
coord.MarkControlIssued(r2.Record);
coord.SettleControlFailure(r2.Record, "TIMEOUT");
T("rs.abandoned", coord.State == "faulted" && coord.AbandonedRestart && !coord.RestartReservationHeld
	&& coord.Fault == DebugSessionCoordinator.FaultKind.ControlFault);
// abandoned 后同 process 移除 → restart_failed 终局
var rrem2 = coord.ObserveProcessRemoved(coord.ActiveSessionId, coord.Generation, true, 0);
T("rs.rem-after-abandoned", rrem2.Accepted && rrem2.Outcome == "unexpected-exit" && coord.State == "idle");

// ---- ownership_lost 与 recovery ----
coord.BeginLaunch("req-12", "net48-exe", "net48", "x64");
coord.MarkLaunchClaimSucceeded(false, null);
coord.MarkOwnershipLost("req-12", new[] { (4242, "clr4", "net48", "x64") });
T("ol.faulted", coord.State == "faulted" && coord.Fault == DebugSessionCoordinator.FaultKind.OwnershipLost);
// Y* 例外不覆盖 ownership_lost
T("ol.terminate-rejected", !coord.TryBeginControl(ControlOperation.Terminate, "req-13").Admitted);
T("ol.recovery", coord.Recover("manager_became_idle_without_new_objects") && coord.State == "idle");
var olevs = coord.ReadEvents(coord.LastSessionId, 0, 100, null);
T("ol.evt-order", olevs.Events[olevs.Events.Count - 1].Contains("\"reason\":\"ownership_recovered\"")
	&& olevs.Events[olevs.Events.Count - 3].Contains("\"kind\":\"ownership_lost\""));

Console.WriteLine($"pass={pass} fail={fail}");
return fail == 0 ? 0 : 1;
