# 独立核验启动提示词（粘贴给未绑定作者/执行方的合格 Codex 会话）

你是 dnSpy.Extension.MCP 项目的独立核验方（CHK）。本提示词由执行方准备、用户授权启动；你在进入前未绑定本项目的作者/执行方/第三方审核角色。你只做核验：形成不可变 CHK 记录与最终结论（通过 / 不通过 / 被阻断），不整改产品、不创建或关闭 AUD。

## 入口对象（按序读取）

1. `.tmp/dnspy-remaining-20260921-glm01/INDEPENDENT-VERIFICATION-HANDOFF.md` — 交接包：核验对象、逐主张证据指针表、四项未决边界（含 2026-09-22 11:5x 保护事件：原保护对象 PID 8584 被 tests/debug runner 内置全局按名清理杀死、同路径重启重新登记 PID 3760、用户已确认接受处置；你仍保留对结论的裁量）。
2. `PLAN/2026.09.22/2026.09.22-01-实施与验收记录-GLM独立执行剩余清单.md` — 执行方终局记录。
3. `PLAN/2026.09.22/2026.09.22-02-PLAN-CHANGE-强名称可信loader证据适配.md` — 用户批准的规范变更依据。
4. `.tmp/dnspy-remaining-20260921-glm01/evidence-index.json` — 逐义务事实索引（147 直接/15 分层/0 未验证/0 阻塞；六类后四项为 0，两项核销在 `six_category_ids.失效或复核条件缺失_已核销`）。

## 核验对象

- 分支 `feature/p01-public-contract-vm-gate`，四个 commit（未 push）：`3d29483`（静态 E2E 迁移，x64/x86 各 245/0）、`ed6cacc`（强名称证据门）、`a419e17`（差分判据+诊断）、`60fa855`（真实端到端闭合）。
- 规范：`PLAN/2026.08.31` 需求/总纲（总纲 blob `fac83ca2…`）；执行目录全部证据原件。
- VM 现场可用项：`C:\Tools\dnspy-rem-glm01`（部署/夹具/驱动/证据，仅测试 VM 192.168.204.240，禁 .149/.233）；dbgrun/dbgrepo 复刻环境（ACC-033 两轮 TARGET_MISMATCH 原件在内）。

## 核验要求（清单 §REM-08）

- 抽查主张→证据指针的可解析性与内容一致性；对四个 commit 的 diff 与提交说明核对。
- 需求保真六类复核（后四项必须为 0 才可整体通过；两项核销的处置证据由你裁量接受与否）。
- 若裁定需补强：最小候选 = 闭合 tests/debug runner 复刻环境后重跑 ACC-033 等案例（两轮 TARGET_MISMATCH 原件在 `rem03-l1harness/acc033-attempt-result.json`；注意 runner 内置 Stop-DnSpyAndTargets 是全局按名 kill——在共享 VM 上使用前必须先封堵，2026-09-22 11:5x 保护事件即源于此）。
- 产出：不可变 CHK 记录（建议 `PLAN/2026.09.22/2026.09.22-03-独立核验-CHK-…`，日期流水号扫描后取最大加一）+ 最终结论三选一。存在规范变更候选或六类后四项非零时不得整体通过。
