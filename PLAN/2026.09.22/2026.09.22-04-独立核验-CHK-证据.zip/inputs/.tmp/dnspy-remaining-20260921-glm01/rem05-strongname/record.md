# REM-05 强名称动态因果（2026-09-22 01:1x）

## 现状核查（当前 HEAD 3d29483，产品代码=8b24019）
- `Editing/EditTransactionCoordinator.cs` `ValidateStrongNameEvidence`（839-864行）保持 T027-R02 的 fail-closed 门：结构/适用性检查后恒拒，原因精确（"current debugger API exposes only the throwing module and exception sample data; it does not identify a CLR loader validation source or the assembly whose binding failed"）。
- 代码同一性：git 核对 `02057f7 fix: reject unproven strong-name removal evidence` 之后该文件仅 2 个提交触碰，diff 中强名称相关行数=0 → 门函数字节未变。
- T027-R02 双架构 VM 负例矩阵（自抛同 HRESULT / 依赖抛错 / 跨 session / 无效 cursor / 正常退出 / 无签名 全部拒绝、事务回滚 idle）：按代码同一性适用当前候选 net48=48096d2a 的门路径。原件：`.tmp/dnspy-sol-fixes-20260919-01/T027-R02-work/evidence/`（远端/本地 SHA 已由主控核对）。
- 白盒探针 P03StoreHarness --strong-name-evidence：net10.0-windows(WPF) 不能在 Linux 运行；VM 无完整源码树可即建（本轮未重建）——以代码同一性+历史 VM 证据替代，范围注明。

## 判定（按清单 REM-05.3）
- 环境与可靠事件来源不足：dnSpy 6.6.0 公开调试契约（DbgMessageExceptionThrownEventArgs）无 loader provenance、无失败绑定目标身份；授权 runtime 内不能产生可核准的真实动态正例。**不把 always-reject 称功能完成，不放宽来源。**
- 授权成功分支（清单 REM-05.4）：前置未满足 → NOT_RUN/BLOCKED。
- PLAN-CHANGE 候选（T027-R02 已识别，维持未登记未批准状态）：可信 loader provenance 与真实 failed-binding target 证据适配（debug backend → retained evidence → transaction matcher → one-time 消费边）。此为规范层变更，超出本清单对执行方的授权，留用户/规范作者裁决。

## ACC-016 状态
维持 **阻塞**（7 义务：默认编辑保留身份/条件分支明确/入站影响报告等成功路径义务未闭合）。ACC-028/总体验收保留此前置阻碍（清单 §REM-05 通过条件）。
