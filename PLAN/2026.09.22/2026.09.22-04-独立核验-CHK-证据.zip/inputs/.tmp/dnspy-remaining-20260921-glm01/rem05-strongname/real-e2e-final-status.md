# 强名称真实端到端终态（2026-09-22 09:4x）

## 已实证（本轮）
1. 真实 loader 强名称验证失败自然产生：Wow6432Node+64 位双键 AllowStrongNameBypass=0（授权，**已于 09:3x 全部恢复默认**）下，host(HostApp.exe, x86) 引用完全签名+签名区篡改目标（sn -vf 失败/元数据完好），CLR 抛 FileLoadException。
2. 真实事件全字段采集：cursor 8 事件 payload 含 type=System.IO.FileLoadException、loader-authored 完整身份消息、**hresult=-2146233318=0x8013DE1A**（外层真实值；消息文本内层 0x8013141A——常量集合已按此双值修正）。
3. 四判据分类器完整实现并部署（HRESULT 集合 + loader-authored 身份 + 属性缺失时的引用闭包差集：host 自身元数据 AssemblyRefs(token 匹配) ∩ 会话已加载模块差集——均为不可伪造调试器事实）；本地构建 778cc734 与 VM 双宿主一致。
4. 白盒与 MCP 级（seam 证据流）全绿维持；T027 反例拒绝维持。

## 最后一格（未闭合，根因已定位）
真实事件下 StrongNameRejection 未生成：exception 事件的 payload 含 hresult（WritePauseDetails 新字段）但 strong_name_gate 诊断字段缺失 ⇒ 分类 note 为空 ⇒ 断点在 CollectBreakInfos 产出的 BreakInfoObservation 到 WritePauseDetails 之间的管道重建处丢失 internal 属性（候选：ObservePaused(协调器 359 行)内部对 breakInfos 的中转/重建）。属结构性小缺陷，非信任模型问题。

## 复现资产（VM 就绪，免重建）
- sn-e2e 目录：HostApp.exe（引用 56cdca22 token 身份）+ 篡改 SignedTarget.dll；fixtures\remglm01.snk/pub.pk/StrongHost3.cs/SignedTarget.dll(净)。
- 驱动：repo\sn_real2.py（逐步打点版）；运行器 ps_real2；篡改器 ps_sh3b（含双键注册表设置，**测后须再恢复两视图**）。
- 下一手：核对 ObservePaused→WritePauseDetails 间 BreakInfoObservation 是否被仅用公共构造参数重建；修后免注册表可用 seam 对照、真实流复跑 ps_real2 即闭合。
