# REM-04 debug ACC-033 租约反例（2026-09-22 00:5x）

对象：VM .240 自有根 C:\Tools\dnspy-rem-glm01\lease04（三根独立、端口16414、DNMCP_TEST=1）；
宿主 host-x64（插件 net48 48096d2a）；目标 csc 编译 ArgvFixture x64 net48（自编译，sha 每轮记录于 lease04-result.json）。

## 判别力对照（debug ACC-033 租约腿闭合）

| 操作 | 无租约对照 | 有租约(session running, gen1) | 判别 |
| --- | --- | --- | --- |
| overwrite (Open Write None) | SUCCEEDED | IOException 正由另一进程使用 | ✓ |
| replace (File.Replace) | SUCCEEDED | IOException 另一进程正在使用 | ✓ |
| reparse-replace (junction 源路径 Move -Force 到目标) | SUCCEEDED | IOException 拒绝（文本为 already-exists 类，但与对照成功成对，且 sha 不变零副作用） | ✓（成对判别） |
| delete | SUCCEEDED | IOException 正由另一进程使用 | ✓ |
| rename | SUCCEEDED | IOException 另一进程正在使用 | ✓ |
| root-rename（操作进程 CWD 显式置于 C:\ 根外） | SUCCEEDED | IOException 另一进程正在使用 | ✓（排除 CWD 句柄归因，租约句柄为因） |

租约期间 sha 不变 ✓；六次尝试后 debug_status 仍 running（会话不受影响）✓；debug_terminate 后 overwrite SUCCEEDED（租约即阻断者）✓。

相对 T042-R02 的增量：
1. reparse-replace 腿由"双向 already-exists 无判别力"改为"junction 源路径替换"构造，无租约对照成功、有租约被拒——判别力成立（错误文本仍非共享冲突类，如实记录）。
2. root-rename 以 CWD 置根外成对运行，阻断原因归因于租约句柄（不再与进程 CWD 混淆）。
3. 新增 replace(File.Replace) 腿作为第四类替换反例。

## 环境分支（BLOCKED，如实记录）
- 可读非 NTFS 卷：VM 卷枚举 = C:NTFS、E:NTFS、无盘符FAT32固定卷(0GB,系统分区,挂载/指派盘符属系统更改禁止)、D:CD-ROM无媒体。按清单不得格式化/挂载/改系统凑前提 → 子分支 BLOCKED。最小恢复条件：用户授权为现有 FAT32 卷指派盘符，或接入可移动 FAT32 媒体。
- evidence-gate.log 悬空引用：T042-R02 已核明为 runner 框架怪癖（PS5.1 空数组管道 Set-Content 不建文件；通过路径合法不存在），不在本轮补造。

## 清理
自有 dnSpy 已停、T.exe 目标进程被 terminate 回收（按路径过滤核零残留）、端口 16414 释放、保护 8584 全程未触碰。
