#!/usr/bin/env python3
"""Reusable windows-mcp caller. Usage: mcp_call.py <tool> <json-args-file-or-inline>"""
import json, urllib.request, sys, time
URL = "http://192.168.204.240:28787/mcp"
class Client:
    def __init__(self):
        self.sid = None
    def post(self, payload, timeout=180):
        req = urllib.request.Request(URL, data=json.dumps(payload).encode(), method="POST")
        req.add_header("Content-Type", "application/json")
        req.add_header("Accept", "application/json, text/event-stream")
        if self.sid: req.add_header("Mcp-Session-Id", self.sid)
        r = urllib.request.urlopen(req, timeout=timeout)
        if r.status == 202: return None
        body = r.read().decode(errors="replace")
        sid = r.headers.get("Mcp-Session-Id")
        if sid: self.sid = sid
        for line in body.splitlines():
            if line.startswith("data:"):
                return json.loads(line[5:])
        return json.loads(body) if body else None
    def init(self):
        r = self.post({"jsonrpc":"2.0","id":0,"method":"initialize","params":{"protocolVersion":"2025-03-26","capabilities":{},"clientInfo":{"name":"glm-remaining","version":"0.1"}}})
        self.post({"jsonrpc":"2.0","method":"notifications/initialized"})
        return r
    def call(self, name, args, timeout=180):
        r = self.post({"jsonrpc":"2.0","id":int(time.time()*1000)%100000,"method":"tools/call","params":{"name":name,"arguments":args}}, timeout)
        if r and "result" in r:
            c = r["result"].get("content",[])
            return "".join(x.get("text","") for x in c if x.get("type")=="text")
        return json.dumps(r, ensure_ascii=False)
if __name__ == "__main__":
    tool = sys.argv[1]
    args = json.loads(sys.argv[2]) if len(sys.argv) > 2 else {}
    timeout = int(sys.argv[3]) if len(sys.argv) > 3 else 180
    c = Client(); c.init()
    out = c.call(tool, args, timeout)
    print(out if isinstance(out, str) else json.dumps(out, ensure_ascii=False, indent=1))
