#!/usr/bin/env python3
"""Run a PowerShell script file (UTF-8, BOM-less) on the VM via windows-mcp. Usage: mcp_ps.py <script.ps1> [timeout]"""
import sys, json, base64
sys.path.insert(0, ".tmp/dnspy-remaining-20260921-glm01/tools")
from mcp_call import Client
script = open(sys.argv[1], encoding="utf-8").read()
b64 = base64.b64encode(script.encode("utf-16-le")).decode()
cmd = f"$s=[Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('{b64}')); iex $s"
timeout = int(sys.argv[2]) if len(sys.argv) > 2 else 120
c = Client(); c.init()
print(c.call("PowerShell", {"command": cmd}, timeout))
