#!/usr/bin/env python3
"""Upload local file to VM: b64 chunks via FileSystem, decode+verify via PowerShell."""
import sys, base64
sys.path.insert(0, ".tmp/dnspy-remaining-20260921-glm01/tools")
from mcp_call import Client
local, vb64, vfinal = sys.argv[1], sys.argv[2], sys.argv[3]
data = base64.b64encode(open(local, "rb").read()).decode()
CH = 48000
c = Client(); c.init()
chunks = [data[i:i+CH] for i in range(0, len(data), CH)] or [""]
c.call("FileSystem", {"mode": "write", "path": vb64, "content": chunks[0]})
for ch in chunks[1:]:
    r = c.call("FileSystem", {"mode": "write", "path": vb64, "content": ch, "append": True})
    if "Append" not in str(r): print("WARN:", r)
print(f"sent {len(chunks)} chunks, {len(data)} b64 chars")
ps = (f"$b=[IO.File]::ReadAllText('{vb64}');"
      f"$dst='{vfinal}'; New-Item -ItemType Directory -Force -Path (Split-Path $dst) | Out-Null;"
      f"[IO.File]::WriteAllBytes($dst,[Convert]::FromBase64String($b));"
      f"$h=(Get-FileHash $dst -Algorithm SHA256).Hash.ToLower(); $len=(Get-Item $dst).Length; \"decoded=$len sha=$h\"")
print(c.call("PowerShell", {"command": ps}, 60))
