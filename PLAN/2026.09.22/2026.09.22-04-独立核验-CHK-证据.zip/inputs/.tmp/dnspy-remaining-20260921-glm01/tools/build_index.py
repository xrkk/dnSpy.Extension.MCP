#!/usr/bin/env python3
"""REM-01: build v4 per-obligation fact index = T029 v3 baseline + T030-T045 deltas."""
import json, copy, os, datetime
SRC = ".tmp/dnspy-sol-fixes-20260919-01/T029-R03-work/acc-fact-index.json"
OUT = ".tmp/dnspy-remaining-20260921-glm01/evidence-index.json"
OLD = ".tmp/dnspy-glm-acceptance-20260920-01"
SOL = ".tmp/dnspy-sol-fixes-20260919-01"

v3 = json.load(open(SRC))
ent = {e["acc"]: e for e in v3["entries"]}

def loc(p): return p

# ---- deltas: source refs relative to repo root ----
D = {}
def delta(acc, **kw):
    D.setdefault(acc, []).append(kw)

delta("ACC-005", source="T033-R01/T034-R01..R03/T036-R01..R05 验收",
      kind="chain-fix+regression",
      facts=["T034 R3 PASS(限基础签名修复范围): 双架构v1/v2版本相位回归闭合",
             "T036 R5 PASS(修复范围含Codex接手自检): 导出完整身份/manifest hash门/reader双架构重载",
             "T032 R2 B3 的 pristine import→commit EDIT_VALIDATION_FAILED 已由T033定位/T034修复/T036闭合"],
      locators=[f"{OLD}/repair-t034-r03/orchestration-r3-summary.json",
                f"{OLD}/repair-t036-r05/exports/manifest.json", f"{OLD}/repair-t036-r05/reports/x64.json"],
      obligation_status={"RACC-005.C1.O2": ("有直接证据","T036 R5 reader双架构重载+导出链闭合")},
      note="C1.O1诊断/C1.O3内嵌调试信息仍开放（REM-06逐字段匹配PdbState/诊断）")
delta("ACC-012", source="T036-R03 验收", kind="regrun",
      facts=["ACC012 source 去重 pass（15白盒+3摘要158下载SHA逐件匹配）"],
      locators=[f"{OLD}/repair-t036-r03"], note="状态不变，补充分层证据")
delta("ACC-013", source="T034-R03 验收(PASS)", kind="regression-pass",
      facts=["双架构 v1_exact/v1_drift/v2 六job exit0；主定位 v1拒绝迁移/显式接纳 及 v2需确认/unverified拒绝 关键断言",
             "原'待主会话裁决'的v1/v2语义已由主控在T034链路按现行P03裁决完成"],
      locators=[f"{OLD}/repair-t034-r03/orchestration-r3-summary.json"],
      obligation_status={
        "RACC-013.C1.O1": ("有直接证据","T034 R3 v1_exact/v1_drift job"),
        "RACC-013.C1.O2": ("有直接证据","T034 R3 v1拒绝迁移断言"),
        "RACC-013.C2.O1": ("有直接证据","T034 R3 v2 job"),
        "RACC-013.C2.O2": ("有直接证据","T034 R3 v2需确认断言"),
        "RACC-013.C3.O1": ("有直接证据","T034 R3 显式接纳断言"),
        "RACC-013.C3.O2": ("未验证","裁决完成但未单列验证；REM-06"),
        "RACC-013.C4.O1": ("未验证","未知版本拒绝未在六job内；REM-06"),
        "RACC-013.C4.O2": ("未验证","unverified无副作用子句未单列；REM-06")})
delta("ACC-021", source="T032-R01/R02 验收(B1/B2有效)", kind="partial-pass",
      facts=["主以原tools/list schema逐原始parsed独立重验(两架构17+18工具)",
             "edit_recover structuredContent 经注册表outputSchema独立验证 CONFORMS；18/18编辑工具有真实成功输出",
             "B3干净失败+module_update对照核准；import失败已由T034/T036闭合",
             "IMP-007文本25 vs 当前18公开edit_*工具数冲突保留（规范回流候选，REM-07）"],
      locators=[f"{OLD}/work-r02/byte-exact", f"{OLD}/T032-R02-补齐恢复输出并核准导入反例.result.md"],
      obligation_status={
        "RACC-021.C1.O1": ("有直接证据","主独立parsed重验全部工具schema"),
        "RACC-021.C3.O1": ("有直接证据","edit_recover CONFORMS+18工具输出，seam分层保留")}),
delta("ACC-022", source="T030-R02 验收(PASS,限文档/注册表+.240部署) + T040-R01(通过,限新候选)", kind="partial-pass",
      facts=["注册表/发布文档同步PASS；.240迁移部署复验final进程端口空",
             "T040闭合T039原生UI退出/持久化目标（隐藏窗口根因；双架构18项字段表仅port差异）"],
      locators=[f"{SOL}/T030-R02-work/vm240-summary.json", f"{SOL}/T030-R02-work/exporter-regression-summary.json",
                f"{OLD}/hidden-window-t040/results.json"],
      obligation_status={
        "RACC-022.C2.O1": ("有直接证据","T030 R2 README同步"),
        "RACC-022.C2.O2": ("有直接证据","T030 R2 MCP说明"),
        "RACC-022.C2.O3": ("有直接证据","T030 R2 完整测试提示词"),
        "RACC-022.C2.O4": ("有直接证据","T030 R2 定向提示词")}),
delta("ACC-027", source="T031-R01 验收(PASS)", kind="full-pass",
      facts=["主重跑77项证据检查，32件artifact/manifest字节hash核准；每架构8次成功dump+1次真实restart",
             "16格跨架构/generation/epoch/module覆盖；当前句柄无TARGET_MISMATCH；既有4次驱动/取证时序失败保留"],
      locators=[f"{SOL}/T031-R01-work/byte-exact/x64/matrix-evidence.json",
                f"{SOL}/T031-R01-work/byte-exact/x86/matrix-evidence.json",
                f"{SOL}/T031-R01-work/orchestration-summary.json",
                f"{SOL}/T031-R01-work/evidence-verification.json"],
      obligation_status={o: ("有直接证据","T031 R1 主核") for o in [
        "RACC-027.C1.O1","RACC-027.C1.O2","RACC-027.C1.O3","RACC-027.C1.O4",
        "RACC-027.C2.O1","RACC-027.C2.O2","RACC-027.C2.O3"]})
delta("ACC-028", source="T037-R01..R04 验收(均PARTIAL) + T043/T044/T045链", kind="blocked-open",
      facts=["T037 R2 明确 ACC028 未通过；静态32 schema≠32行为；VM Ran64 skipped2=62执行",
             "静态E2E(套件ACC001)在T043确认static-e2e-exit0 fail（保存契约冲突）；T044修复会话/配置隔离；T045 R01修复根层保存拒绝(PARTIAL)",
             "T045 R02 在途未回传：commit 25e76ad(静态E2E对齐P03导出契约+path matrix)未经接收/验收"],
      locators=[f"{OLD}/regression-t037-r02", f"{OLD}/regression-t037-r04/results.json",
                f"{OLD}/debug-remaining-t043/ACC-001-514ec6b230e7-result.json",
                f"{OLD}/static-session-t044-r04", f"{OLD}/save-export-t045"],
      note="REM-02消化T045 R02在途成果后重评；UI持久化已由T040闭合不重用T037旧BLOCKED")
delta("ACC-029", source="T041-R02 验收(ACC029行为接受)", kind="namespace-clarification",
      facts=["T041 R02 'ACC-029' 为 tests/debug 命名空间调试矩阵用例(对dnspy.debug.test.v1.schema校验)，非总纲ACC-029(P03磁盘占用)",
             "总纲RACC-029.C2.O1(原子更新瞬态双份占用)仍开放；历史T022/T023证据按REM-06匹配"],
      locators=[f"{OLD}/coreclr-t041-r02/results.json"],
      note="命名空间纪律：本条不因此升级")
delta("ACC-030", source="T041-R02 R4边界证据 + T042-R01/R02(92项runner)", kind="layered-support",
      facts=["T041 R4单变量边界：根内成功/根外TARGET_MISMATCH且dbg_start_calls增量=0（真实引擎拒绝零副作用）",
             "T042 92项runner通过(主逐JSON核)七案17+15+13+10+10+14+13；真实引擎/负例/注入/框架门分开；覆盖未全部关闭",
             "debug命名空间同号ACC仅按语义关联（清单§3/§REM-07）"],
      locators=[f"{OLD}/coreclr-t041-r02/r4-boundary.json", f"{OLD}/debug-controls-t042-r02/p1-verification.json",
                f"{OLD}/debug-controls-t042-r02/p2-summary.json"],
      note="保持分层；REM-06/07按语义结链后升级")
delta("ACC-014", source="T045-R01 验收(PARTIAL) + P03契约澄清", kind="contract-recheck",
      facts=["主控纠正：现行P03§9/§10已定安全输出契约(saved_to/bytes_written/backup_path=null/source_preserved)；旧覆盖/backup断言系错误指令",
             "T045 R01修复EnsurePathBelowArtifactRoot根层等值误拒(8b24019)；samples拒绝属另一问题",
             "旧direct证据基于旧断言者需按现行契约重核（REM-02执行）"],
      locators=[f"{OLD}/save-export-t045/contract2-abs-diag.json", f"{OLD}/save-export-t045/verify-clean-candidate.json"],
      note="规范未变（SHA一致），测试期望纠正；REM-02重跑保存契约回归")

REM_MAP = {
 "ACC-001":"REM-06","ACC-002":"-","ACC-003":"REM-06","ACC-004":"REM-06","ACC-005":"REM-06(诊断/PdbState)",
 "ACC-006":"REM-06","ACC-007":"REM-06","ACC-008":"REM-06","ACC-009":"REM-06","ACC-010":"REM-06",
 "ACC-011":"REM-06","ACC-012":"-","ACC-013":"REM-06(余3义务)","ACC-014":"REM-02","ACC-015":"-",
 "ACC-016":"REM-05","ACC-017":"-","ACC-018":"-","ACC-019":"-","ACC-020":"REM-06",
 "ACC-021":"REM-06/07(错误矩阵+18/25回流)","ACC-022":"REM-07","ACC-023":"REM-06","ACC-024":"-",
 "ACC-025":"-","ACC-026":"REM-06","ACC-027":"-(已闭合)","ACC-028":"REM-02/07","ACC-029":"REM-06(瞬态)",
 "ACC-030":"REM-06/07"}

entries = []
for e in v3["entries"]:
    ne = copy.deepcopy(e)
    acc = e["acc"]
    for dd in D.get(acc, []):
        ne.setdefault("merge_deltas", []).append({k: v for k, v in dd.items()})
    ne["rem_mapping"] = REM_MAP.get(acc, "REM-06")
    # apply obligation status overrides
    for dd in D.get(acc, []):
        for oid, (st, why) in dd.get("obligation_status", {}).items():
            for c in ne["clauses"]:
                for o in c["obligations"]:
                    if o["id"] == oid:
                        o["status"] = st
                        o.setdefault("merge_notes", []).append(f"{dd['source']}: {why}")
    # recompute aggregates
    sts = [o["status"] for c in ne["clauses"] for o in c["obligations"]]
    ne["uncovered_obligations"] = [o["id"] for c in ne["clauses"] for o in c["obligations"]
                                   if o["status"] in ("未验证","失败","阻塞","待主会话裁决")]
    ne["uncovered"] = [c["id"] for c in ne["clauses"]
                       if any(o["status"] in ("未验证","失败","阻塞","待主会话裁决") for o in c["obligations"])]
    if all(s == "有直接证据" for s in sts): ne["status"] = "有直接证据"
    elif all(s in ("有直接证据","有分层证据") for s in sts): ne["status"] = "有直接证据" if False else "有分层证据"
    elif any(s in ("有直接证据","有分层证据") for s in sts): ne["status"] = "有分层证据"
    elif any(s == "阻塞" for s in sts): ne["status"] = "阻塞"
    elif any(s == "待主会话裁决" for s in sts): ne["status"] = "待主会话裁决"
    else: ne["status"] = "未验证"
    for c in ne["clauses"]:
        cost = [o["status"] for o in c["obligations"]]
        c["status"] = ("有直接证据" if all(s=="有直接证据" for s in cost)
                       else "有分层证据" if all(s in ("有直接证据","有分层证据") for s in cost)
                       else "阻塞" if any(s=="阻塞" for s in cost)
                       else "待主会话裁决" if any(s=="待主会话裁决" for s in cost)
                       else "有分层证据" if any(s in("有直接证据","有分层证据") for s in cost)
                       else "未验证")
    entries.append(ne)

# six-category obligation classification
cats = {"应承接":0,"完整":0,"未落点":0,"语义弱化":0,"不可验收":0,"失效或复核条件缺失":0}
cat_ids = {k:[] for k in cats}
for e in entries:
    for c in e["clauses"]:
        for o in c["obligations"]:
            s = o["status"]
            if s == "有直接证据": cats["完整"]+=1; cat_ids["完整"].append(o["id"])
            elif s == "有分层证据": cats["应承接"]+=1; cat_ids["应承接"].append(o["id"])  # layered: carry with upgrade path
            elif s == "阻塞": cats["应承接"]+=1; cat_ids["应承接"].append(o["id"])
            else: cats["应承接"]+=1; cat_ids["应承接"].append(o["id"])
# specific non-default observations
cat_ids["失效或复核条件缺失"] = ["T037R1自报证据9件hash不匹配(l4-evidence/summary.json,state.log,ACC-001/004/008/022/029/030/034.log)—该轮自报不能直接采信，验收已按原件重核",
                                "ACC-014旧direct证据中基于backup/覆盖断言的部分需按现行P03§9/§10重核（REM-02）"]
cats["失效或复核条件缺失"] = len(cat_ids["失效或复核条件缺失"])
cat_ids["语义弱化"] = ["（暂无；合并中未发现现行实现弱化规范语义的验收事实）"]

out = {
 "schema_version": "dnspy.remaining.acc-fact-index.v4",
 "run_id": "dnspy-remaining-20260921-glm01",
 "base": {"schema": v3["schema_version"], "run": v3["run_id"], "object": v3["object"],
          "imported_from": SRC},
 "object": {
   "branch": "feature/p01-public-contract-vm-gate",
   "head": "25e76ad090ed23e2ad466c687d8be78c0e834b9c",
   "head_note": "含T045 R02在途未验收提交25e76ad；产品代码自8b24019(T045R01)后未变",
   "spec_blobs": {
     "需求提炼": "fb53407f05aa3e3d6e101f8b269b9068fce304a5b00b46a010b4ecbbf0ba6229",
     "总纲": "fac83ca2ca6fee3d00e8dcbd6b77e9fb70bb37e8dd076f01b1685741c1e12e8c",
     "P03": "879e9c82353dac7e2c8067669c590c8f8cfbc5ed9f9ca3f566adf62fae12a671",
     "P08": "396ab0ca3af120c41ff9b1567dc57cddc8e9d79c7762eecacb1e9491ff70d496",
     "P09": "857e02d011990dc716fab03aba19060830d15cb8a364112d75b1a8fdca0b3b3f"},
   "denominator_note": "分母沿用现行规范重算：30 ACC/72子句/162义务，与T029 v3一致（总纲SHA与清单§8快照相同，规范未漂移）"},
 "status_vocabulary": v3["status_vocabulary"],
 "status_rule": v3["status_rule"] + " v4合并规则：仅主控验收明确接受且原始定位符存在的事实才升级义务状态；命名空间混同的编号不升级（清单§3）。",
 "six_category_counts": cats,
 "six_category_ids": cat_ids,
 "entries": entries,
 "generated_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds"),
}
json.dump(out, open(OUT,"w"), ensure_ascii=False, indent=1)
# summary
import collections
accst = collections.Counter(e["status"] for e in entries)
obst = collections.Counter(o["status"] for e in entries for c in e["clauses"] for o in c["obligations"])
print("ACC:", dict(accst))
print("OBL:", dict(obst))
print("six:", cats)
for e in entries:
    tot = sum(len(c["obligations"]) for c in e["clauses"])
    unc = len(e["uncovered_obligations"])
    print(f"{e['acc']} {e['owner']:4s} {e['status']:8s} {tot-unc}/{tot}  REM={e['rem_mapping']}")
