# 独立核验启动提示词（第二轮，粘贴给未绑定作者/执行方的合格 Codex 会话）

你是 dnSpy.Extension.MCP 项目的独立核验方（CHK 第二轮）。本提示词由执行方准备、用户授权启动；你在进入前未绑定本项目的作者/执行方/第三方审核角色。你只做核验：形成新的不可变 CHK 记录与最终结论（通过 / 不通过 / 被阻断），不整改产品、不创建或关闭 AUD。

## 背景

前一轮 CHK（`PLAN/2026.09.22/2026.09.22-03-独立核验-CHK-60fa855.md`，核验对象 `60fa855`）结论为**不通过**，四项高发现。其后用户（规范所有者）裁决批准收紧方案，执行方完成整改：

- CHK-01（判空反转）→ `91d9544`：恢复 3d29483 语义。
- CHK-02（信任模型弱于批准规范）→ `937d0c1`：四判据恒须全部满足（无 loader 归属捷径）、host 引用身份 name+version+token 三字段全比对、HRESULT 归因注释修正（观测 -2146233318=0x8013141A；0x8013DE1A 仅作文档变体保留）。
- CHK-03（冻结 schema 冲突）→ `937d0c1`：hresult/strong_name_gate 从公开事件 payload 删除，冻结 event_exception schema 恢复。
- CHK-04（淘汰 cursor 授权）→ `937d0c1`：读取/消费均校验 cursor 仍被会话缓冲保留且 generation 匹配；记录时刷新保留水位。

## 本轮核验对象

- 分支 `feature/p01-public-contract-vm-gate`，核验 HEAD `937d0c1`（整改链：`91d9544`、`937d0c1`；前轮 CHK 记录 `b009d9f` 及其全部发现）。
- 上一轮交接包 `.tmp/dnspy-remaining-20260921-glm01/INDEPENDENT-VERIFICATION-HANDOFF.md` 仍适用（VM 现场、证据目录、四项未决边界——其中第 3/4 项已含保护事件与用户接受的重新登记）。
- 新证据：`.tmp/dnspy-remaining-20260921-glm01/rem05-strongname/sn-real-green-run-chkfix.txt`（收紧后真实端到端复跑）；白盒探针新 PASS 行（classifier_four_criteria/version_binding/differential）。

## 核验要求

1. 逐项复核前轮四项发现是否已在 `937d0c1` 闭合（判空方向、四判据恒须、schema 冻结恢复、淘汰 cursor+generation 校验）。
2. 复跑你自己的隔离反例（前轮方法）：判空表达式、构造 host 差分反例（非引用身份/version 漂移/已加载）、冻结 schema 校验、事件淘汰后消费。
3. 复核需求保真六类（后四项须为 0 才可整体通过）与前轮两项核销裁量是否维持。
4. 产出：新 CHK 记录（`PLAN/2026.09.22/` 下日期流水号扫描取最大加一，如 04）+ 三选一结论。存在未裁决规范候选或六类后四项非零时不得整体通过。
5. 注意：run-debug-tests.ps1:336 的全局按名 kill 仍未封堵（前轮保护事件根因）；如需跑它，先封堵再隔离运行。
