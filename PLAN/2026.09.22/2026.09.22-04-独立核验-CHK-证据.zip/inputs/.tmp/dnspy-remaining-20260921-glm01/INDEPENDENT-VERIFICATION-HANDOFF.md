# 独立核验交接包（最终版 2026-09-22 10:5x）

## 核验方要求（清单 §REM-08）
- 由 Codex 中**未绑定作者/执行方**的合格会话执行；只形成不可变 CHK 与结论（通过/不通过/被阻断），不整改、不创建/关闭 AUD。
- 建议入口命令序列：先读本文件与 PLAN/2026.09.22-01 记录，再按需抽查下列对象。

## 核验对象
- 分支 `feature/p01-public-contract-vm-gate`，四个 commit（未 push）：`3d29483`（静态 E2E 迁移，x64/x86 各 245/0）、`ed6cacc`（强名称证据门）、`a419e17`（差分判据+诊断）、`60fa855`（真实端到端闭合）。
- 规范：`PLAN/2026.08.31` 需求/总纲（总纲 blob `fac83ca2…` 与清单快照一致）；PLAN-CHANGE 记录 `PLAN/2026.09.22/2026.09.22-02`。

## 核心主张与证据指针（全部相对仓库根）
| 主张 | 证据 |
| --- | --- |
| 义务终态 147 直接/15 分层/0 未验证/0 阻塞；六类后四项全零 | `.tmp/dnspy-remaining-20260921-glm01/evidence-index.json`（含逐义务证据定位符与核销明细） |
| 静态 E2E 双架构全量 245/0 | `…/rem02-vm/e2e_x86_green.txt`、`…/rem06/e2e-x64-green.txt`（授权清理记录 `rem06/auth-kill-record.txt`） |
| ACC-016 真实端到端（loader 拒绝→门→移除→导出无签名→host 重跑） | `…/rem05-strongname/sn-real-green-run.txt`、`record.md`、`real-e2e-final-status.md`（根因链）；注册表已恢复（TASK.md 10:3x） |
| 强名称白盒+MCP 回归 | P03StoreHarness `--strong-name-evidence`（全绿）；`rem06/` sn-mcp 11/11（seam 流） |
| L1 15 组 423 断言 | `…/rem03-l1harness/all15-run.txt` + `adaptations.md`（六组适配溯源） |
| 租约判别力反例 | `…/rem04-lease/lease04-result.json` + `record.md`（非 NTFS 分支 BLOCKED 记录） |
| acc021 归因（运行器误删存储目录）与 C2 矩阵 | `…/rem06/storedel-probe.txt`、`acc021b-run.txt`（九类错误 stable-triple） |
| 工具/文档/宿主一致性（72=32+22+18；dnSpy 6.6.0=最新稳定） | `…/rem06/res-host-probe.txt`；PLAN/2026.09.22-01 §2 |
| 两项观察核销 | evidence-index `six_category_ids.失效或复核条件缺失_已核销`（T037-R03 验收 + ACC-014 14/14） |

## 执行方未决边界（供核验方裁量，非隐藏）
1. 15 项分层：ACC-011 C3.O1（无 headless 原生 undo seam——代码层零集成+独立持久化为分层证据）；ACC-017/030（分层维持，语义结链未升级）。
2. net10 运行时未执行（VM 无 net10 dnSpy 发行树；本地构建候选 `03861ce4…` 就绪）；net48 运行时全程 `48096d2a…`（部署历史快照）与本地构建身份差异属构建环境属性。
3. 调试套件未在最终候选上整体重跑（Debugger/Transport/McpServer 源码自 T042 证据 HEAD `0b3ae0de` 至 `3d29483` 零改动的同一性承继；`ed6cacc`/`a419e17`/`60fa855` 涉及 Debugger 三文件——该同一性已破。**补强已执行**：`60fa855` 源构建上全部 43 个 P03StoreHarness 白盒探针复跑，结果与强名称三 commit 之前的首跑完全一致（同 5 个探针级失败、同原因，均为 T027 时代已知形状：TestIL 无公钥的 capability 拒绝、探针旧 API 形状），`--strong-name-evidence` 探针全绿——证据：`rem03-l1harness/harness-60fa855.txt`。若核验方仍要求 tests/debug 整体重跑：**执行方已尝试**在 VM 复刻隔离环境（git bundle clone 至 `dbgrun`/`dbgrepo`、硬链接 dnSpy 树、36 案 manifest 全量适配），ACC-033 单案两轮跑到 `a33-control-launch` 的 `TARGET_MISMATCH`（租约预检查层，wire/0005 原件与两轮 result.json 已归档 `rem03-l1harness/acc033-attempt-result.json`）——环境复刻细节（如 dotnet10_root 指向等 manifest env 余项）未完全闭合，完整 runner 重跑留作核验方裁量或授权下的续作；强名称三 commit 的调试面回归由 43 探针复跑与本会话 MCP 级租约六操作三相位实测覆盖）。
4. VM 现场：`C:\Tools\dnspy-rem-glm01`（部署/夹具/驱动/证据）；注册表已恢复默认。**保护事件（2026-09-22 11:5x 如实上报）**：原保护对象 PID 8584（`C:\Tools\dnspy-remaining-acc-07332ba\ui\x64\app\dnSpy.exe`，2026-09-15 08:31 启动）在 tests/debug runner 补跑尝试中被该 runner 内置的全局按名清理（`Stop-DnSpyAndTargets`，runner:336）杀死——清单明令禁止的操作经由未审计 runner 发生，执行方过错；已同路径重启并重新登记 PID 3760（启动 2026-09-22T09:46:12Z，exe 同 SHA `4e72f78c…`），原身份不可恢复。该实例无端口/会话，不影响任何本轮证据；核验方对本事件与整体结论的裁量权完整保留。**用户已于 2026-09-22 12:0x 确认接受重新登记处置**（见执行目录 TASK.md 同刻度条目）。

## 保护与不可变
- OLD_RUN（`.tmp/dnspy-glm-acceptance-20260920-01`）全部原件未覆盖；S0038 STOP 单向声明；历史 checkpoint/证据零删除。
- 本执行方（GLM）不宣布"核查通过"；CHK 与最终结论由核验方独立形成。
