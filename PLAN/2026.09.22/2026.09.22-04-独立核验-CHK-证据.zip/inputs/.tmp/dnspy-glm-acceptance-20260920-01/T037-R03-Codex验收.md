# T037 R3 主验收
PARTIAL。结果WORK_STOPPED/done已核；36个j2下载本地SHA=远端清单SHA逐件复核，j1各run2路径亦与旧collect清单一致。接受阶段映射纠正，run1原collect已被覆盖，不能称run1原件追溯完整；24pass/12fail是最小轮+原轮+重跑的当前案例账，不宣称同一轮36案全矩阵。
监听观测仍不闭合：j3_health_loop.py与j4_control.py仍按OwningProcess找HttpListener，不会看到PID4；报告已承认缺陷，但H1“进程无socket所以证伪端口漂移”仍依赖无效观察。j4-byport-loop.json仅概括成功，没有失败尝试的逐次命令/HTTP/设置/绑定原件且verdict已断言http.sys残留原因，与结果“根因未定位”冲突；只接受成功例事实，不接受广义根因或“产品完全正常”。管理端可用、资源数近似只能削弱假设不能证伪全部。
J5 root配置再次错误后仍未跑两项。相关配置错误存在定向停滞1（已明确先验root而未做到）；监听卡点有PID4观测新增证据，计数0。不是按父任务ROUND计失败。
不批准或要求VM级ETW/procmon；尚可在现有权限完成正确最小观测与自有进程诊断。下一R4限正确HTTP loop+root预检+两测试，不重复矩阵，不改产品。
