import collections, json, pathlib
root = pathlib.Path(__file__).resolve().parents[2]
d = json.loads((root / '.tmp/dnspy-remaining-20260921-glm01/evidence-index.json').read_text())
obligations = [o for e in d['entries'] for c in e['clauses'] for o in c['obligations']]
checks = []
def visit(value, pointer=''):
    if isinstance(value, dict):
        if 'path' in value and 'locator' in value:
            p = pathlib.Path(value['path']); p = p if p.is_absolute() else root / p
            loc = value['locator']; errors = []
            try:
                raw = p.read_text(encoding='utf-8-sig')
                if loc['kind'] == 'json_pointer':
                    selected = json.loads(raw)
                    for key in loc['pointer'].split('/')[1:]:
                        key = key.replace('~1', '/').replace('~0', '~')
                        selected = selected[int(key)] if isinstance(selected, list) else selected[key]
                    text = selected if isinstance(selected, str) else json.dumps(selected, ensure_ascii=False)
                    if 'equals' in loc and selected != loc['equals']: errors.append('equals mismatch')
                else:
                    lines = raw.splitlines()
                    if not 1 <= loc['start'] <= loc['end'] <= len(lines): errors.append('line range out of bounds')
                    text = '\n'.join(lines[loc['start']-1:loc['end']])
                for token in loc.get('contains', []):
                    if token not in text: errors.append('contains missing: ' + token)
            except Exception as exc: errors.append(type(exc).__name__ + ': ' + str(exc))
            checks.append({'index_pointer':pointer, 'path':value['path'], 'locator':loc, 'errors':errors})
        for key, child in value.items(): visit(child, pointer+'/'+key)
    elif isinstance(value, list):
        for i, child in enumerate(value): visit(child, pointer+'/'+str(i))
visit(d)
result = {
    'denominators':[len(d['entries']),sum(len(e['clauses']) for e in d['entries']),len(obligations)],
    'obligation_status_counts':dict(collections.Counter(o['status'] for o in obligations)),
    'six_category_declared_counts':d['six_category_counts'],
    'six_category_id_list_lengths':{k:len(v) for k,v in d['six_category_ids'].items()},
    'direct_without_obligation_refs':[o['id'] for o in obligations if o['status']=='有直接证据' and not o.get('evidence_refs')],
    'locator_count':len(checks),'locator_pass_count':sum(not c['errors'] for c in checks),
    'locator_failures':[c for c in checks if c['errors']],
    'boundary':'Checks locator syntax, range and declared content only; parent merge_deltas may provide additional evidence but cannot imply semantic acceptance.'
}
target=pathlib.Path(__file__).with_name('index-check.json')
target.write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in result.items() if k not in ('locator_failures','direct_without_obligation_refs')},ensure_ascii=False,indent=2))
print('direct_without_obligation_refs',len(result['direct_without_obligation_refs']))
print('failed locators',len(result['locator_failures']))
