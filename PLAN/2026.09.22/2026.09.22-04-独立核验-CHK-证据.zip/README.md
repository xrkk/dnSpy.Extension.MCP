# 第二轮 CHK 隔离证据

对象：937d0c1cce82f26aed82b24a1c9890529dae3d42。未访问 VM，未运行 run-debug-tests.ps1。

在仓库的 .tmp/dnspy-independent-chk-20260922-02/ 布局下：
1. python3 build_probe.py（从固定源码复制协调器等，并原样抽取五参分类器和判空表达式；dnlib 路径见脚本）
2. dotnet run --project probe/Probe.csproj > probe-run.txt 2>&1
3. python3 validate_probe.py（通过表示复核结果与记录一致，其中含确定的产品反例，不表示产品通过）
4. python3 check_index.py（只核对结构化定位符与统计，不是逐义务整体通过）

实际环境 .NET SDK 10.0.400，组件程序 net10.0。生产源未改动；Program.cs 合成 host AssemblyRef 元数据和 BreakInfoObservation。判空 mint stand-in 仅复现对 thread.Id 的解引用。不是全 DebugSessionService、Windows 调试器或真实攻击端到端。probe-run.txt 有 10 个 nullable 编译警告、无错误；构建运行退出 0。

inputs/ 是进入封存时的输入副本，input-manifest.json 列路径、大小及 SHA-256；verify-inputs.json 是封存前再次核对结果。probe-source-manifest.json 记录复制来源和抽取代码哈希。完整核验脚本、组件源码、dnlib.dll 与生成 Host.exe 均封存，省略 bin/obj。运行输出与 schema-result.json/probe-result.json 是本 CHK 新证据。
