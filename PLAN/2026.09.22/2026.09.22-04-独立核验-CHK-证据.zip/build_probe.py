from pathlib import Path
import shutil, hashlib, json
base=Path(__file__).resolve().parent
root=base.parents[1]
out=base/'probe'
source=(root/'Debugger/DebugSessionService.cs').read_text()
start=source.index('\tstatic readonly int[] StrongNameFailureHResults')
end=source.index('\n\tinternal static StrongNameRejectionFacts? ClassifyLoaderStrongNameRejection(string? moduleName, int? hResult, string? message) {', start)
classifier=source[start:end]
(out/'Classifier.cs').write_text('using System; using System.Linq; using System.Collections.Generic; using dnSpy.Extension.MCP.Debugger;\nstatic class Classifier {\n'+classifier+'\n}')
files=['Debugger/DebugSessionCoordinator.cs','Debugger/ControlOperation.cs','Debugger/DebugEventBuffer.cs','Debugger/DebugProtocol.cs','Debugger/PauseCauseArbiter.cs','Execution/VirtualizationClassification.cs','Net48Compat.cs']
for f in files: shutil.copyfile(root/f,out/Path(f).name)
dnlib=Path('/home/adminn/tmp/dnSpyEx/Build/compiled/dnlib.dll')
shutil.copyfile(dnlib,out/'dnlib.dll')
(out/'Probe.csproj').write_text('''<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFramework>net10.0</TargetFramework><Nullable>enable</Nullable><ImplicitUsings>enable</ImplicitUsings></PropertyGroup><ItemGroup><Reference Include="dnlib"><HintPath>dnlib.dll</HintPath></Reference></ItemGroup></Project>''')
# Copy the exact production ternary into a small control-flow probe. The stand-in
# mint function dereferences the thread, as production MintThreadHandle does.
line=next(l.strip() for l in source.splitlines() if 'var threadHandle = eventThread' in l)
(out/'ThreadProjection.cs').write_text('''static class ThreadProjection {
 public sealed class Thread { public int Id = 1; }
 static string MintThreadHandle(Thread thread, int epoch) => "th-" + thread.Id;
 public static string? Project(Thread? eventThread) { int eventPauseEpoch=1;
 '''+line+'''
 return threadHandle; }
}''')
(base/'probe-source-manifest.json').write_text(json.dumps({'source_head':'937d0c1cce82f26aed82b24a1c9890529dae3d42','copied_files':{f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in files},'classifier_extracted_sha256':hashlib.sha256(classifier.encode()).hexdigest(),'thread_expression':line,'dnlib_sha256':hashlib.sha256(dnlib.read_bytes()).hexdigest(),'boundary':'Local component/source-extraction verification, not a Windows VM or full DebugSessionService execution.'},indent=2))
