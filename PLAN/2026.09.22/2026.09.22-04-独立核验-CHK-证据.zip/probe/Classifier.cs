using System; using System.Linq; using System.Collections.Generic; using dnSpy.Extension.MCP.Debugger;
static class Classifier {
	static readonly int[] StrongNameFailureHResults = { unchecked((int)0x8013141A), unchecked((int)0x8013DE1A) };

	static readonly System.Text.RegularExpressions.Regex LoaderAssemblyIdentityRegex = new(
		@"['\u201C\u2018](?<name>[^'\u201C\u201D\u2018\u2019,]+),\s*Version=(?<version>[0-9.]+)(?:,\s*Culture=[^,]+)?,\s*PublicKeyToken=(?<pkt>[0-9a-fA-F]{16})['\u201D\u2019]",
		System.Text.RegularExpressions.RegexOptions.CultureInvariant | System.Text.RegularExpressions.RegexOptions.Compiled);

	/// <summary>Full classification under the tightened PLAN-CHANGE 2026.09.22 semantics
	/// (CHK-20260922-03-02 remediation). ALL FOUR criteria must hold simultaneously, with no
	/// shortcut for any module attribution:
	/// 1. the strong-name failure HRESULT;
	/// 2. the loader-authored identity message parses to name+version+16-hex token;
	/// 3. the reference-closure differential: that exact identity (name AND version AND
	///    token, all three fields) is a strong-named AssemblyRef of the launch host's own
	///    metadata on disk;
	/// 4. no module with that assembly name is in the session's loaded-module set.
	/// Every input is a debugger fact sample code cannot forge: a forged exception naming
	/// an assembly the host does reference and that really fails to load IS the genuine
	/// loader rejection; any assembly the runtime actually loads clears criterion 4.</summary>
	internal static StrongNameRejectionFacts? ClassifyLoaderStrongNameRejection(string? moduleName, int? hResult, string? message,
		string? hostTargetPath, IReadOnlyCollection<string>? loadedModuleNames) {
		if (hResult is null || !StrongNameFailureHResults.Contains(hResult.Value) || string.IsNullOrEmpty(message))
			return null;
		var match = LoaderAssemblyIdentityRegex.Match(message);
		if (!match.Success)
			return null;
		var name = match.Groups["name"].Value.Trim();
		var version = match.Groups["version"].Value.Trim();
		var token = match.Groups["pkt"].Value.ToLowerInvariant();
		if (hostTargetPath is null || loadedModuleNames is null)
			return null;
		if (loadedModuleNames.Any(loaded => string.Equals(loaded, name, StringComparison.OrdinalIgnoreCase)))
			return null;
		if (!HostReferencesStrongIdentity(hostTargetPath, name, version, token))
			return null;
		return new StrongNameRejectionFacts {
			LoaderModule = string.IsNullOrEmpty(moduleName) ? "binding-failure" : moduleName!,
			HResult = hResult.Value,
			AssemblyName = name,
			AssemblyVersion = version,
			PublicKeyToken = token,
		};
	}

	static bool HostReferencesStrongIdentity(string hostPath, string name, string version, string token) {
		try {
			using var host = dnlib.DotNet.ModuleDefMD.Load(hostPath);
			foreach (var reference in host.GetAssemblyRefs()) {
				if (!string.Equals(reference.Name, name, StringComparison.OrdinalIgnoreCase))
					continue;
				// CHK-20260922-03-02: version must match field-by-field — a host referencing
				// v1.0.0.0 must not authorize a message claiming v9.9.9.9.
				if (!string.Equals(reference.Version?.ToString(), version, StringComparison.OrdinalIgnoreCase))
					continue;
				// The ref may carry an 8-byte token or the full public key; dnlib's Token
				// derives the token from either form.
				var refToken = reference.PublicKeyOrToken?.Token?.Data;
				if (refToken is null || refToken.Length != 8)
					continue;
				var hex = string.Concat(refToken.Select(b => b.ToString("x2")));
				if (string.Equals(hex, token, StringComparison.OrdinalIgnoreCase))
					return true;
			}
			return false;
		}
		catch {
			return false;
		}
	}

}