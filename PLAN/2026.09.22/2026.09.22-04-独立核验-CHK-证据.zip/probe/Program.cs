using dnlib.DotNet;
using dnSpy.Extension.MCP.Debugger;
using System.Text.Json;

var results = new Dictionary<string,object?>();
const string token="0011223344556677";
const int hr=unchecked((int)0x8013141A);
const string msg="Could not load file or assembly 'SignedTarget, Version=1.0.0.0, Culture=neutral, PublicKeyToken=0011223344556677'";
var host = new ModuleDefUser("Host.exe") { Kind=ModuleKind.Console };
new AssemblyDefUser("Host",new Version(1,0,0,0)).Modules.Add(host);
var reference = new AssemblyRefUser("SignedTarget", new Version(1,0,0,0), new PublicKeyToken(token));
host.Types.Add(new TypeDefUser("Fixture","UnusedReference",new TypeRefUser(host,"Fixture","Base",reference)));
var hostPath=Path.Combine(AppContext.BaseDirectory,"Host.exe");
host.Write(hostPath); host.Dispose();
bool Classify(string? module, string message, string? path, string[]? loaded, int hresult=hr) => Classifier.ClassifyLoaderStrongNameRejection(module,hresult,message,path,loaded) is not null;
results["classifier"]=new {
    exact_identity_accepted=Classify("mscorlib",msg,hostPath,Array.Empty<string>()),
    attribution_alone_accepted=Classify("mscorlib",msg,null,null),
    version_drift_accepted=Classify("mscorlib",msg.Replace("1.0.0.0","9.9.9.9"),hostPath,Array.Empty<string>()),
    token_drift_accepted=Classify("mscorlib",msg.Replace(token,"8899aabbccddeeff"),hostPath,Array.Empty<string>()),
    nonreferenced_identity_accepted=Classify("mscorlib",msg.Replace("SignedTarget","NotReferenced"),hostPath,Array.Empty<string>()),
    already_loaded_accepted=Classify("mscorlib",msg,hostPath,new[]{"SignedTarget"}),
    wrong_hresult_accepted=Classify("mscorlib",msg,hostPath,Array.Empty<string>(),unchecked((int)0x80131509)),
    no_identity_accepted=Classify("mscorlib","sample supplied text",hostPath,Array.Empty<string>()),
    sample_module_synthetic_message_accepted=Classify("Host",msg,hostPath,Array.Empty<string>()),
    null_module_synthetic_message_accepted=Classify(null,msg,hostPath,Array.Empty<string>()),
    documentation_variant_accepted=Classify("mscorlib",msg,hostPath,Array.Empty<string>(),unchecked((int)0x8013DE1A))
};
results["present_thread_projection"]=ThreadProjection.Project(new ThreadProjection.Thread());
results["absent_thread_projection"]=ThreadProjection.Project(null);

DebugSessionCoordinator Start(string id) {
    var c=new DebugSessionCoordinator(()=>id);
    if(!c.BeginLaunch("launch","start","net-framework","x64") || !c.MarkLaunchClaimSucceeded(false,null)) throw new Exception("launch failed");
    return c;
}
// Record via production ObservePaused, not just the test-only recorder.
long Record(DebugSessionCoordinator c, string id) {
    c.ObservePaused(id,c.Generation,true,new[]{new BreakInfoObservation(PauseCauseArbiter.Exception,0,null,null,true,null,"th-1","mod-1","System.IO.FileLoadException",msg,hr,true,false) {
        StrongNameRejection=new StrongNameRejectionFacts {LoaderModule="mscorlib",HResult=hr,AssemblyName="SignedTarget",AssemblyVersion="1.0.0.0",PublicKeyToken=token}
    }});
    return c.ReadEvents(id,0,4096,null)!.Events.Select(e=>JsonSerializer.Deserialize<JsonElement>(e)).Last(e=>e.GetProperty("kind").GetString()==EventKinds.Exception).GetProperty("cursor").GetInt64();
}
bool Consume(DebugSessionCoordinator c,string id,long cur)=>c.TryConsumeStrongNameFailure(id,cur,"SignedTarget","1.0.0.0",token);
var schema=Start("schema");
Record(schema,"schema");
results["exception_payload"]=schema.ReadEvents("schema",0,32,null)!.Events.Select(e=>JsonSerializer.Deserialize<JsonElement>(e)).Single(e=>e.GetProperty("kind").GetString()==EventKinds.Exception).GetProperty("payload");

foreach(var mode in new[]{"repeat_strong_name","ordinary_events","byte_budget"}) {
    var c=Start(mode); var cursor=Record(c,mode);
    if(mode=="repeat_strong_name") for(int i=0;i<4200;i++) c.WriteStrongNameRejectionForTest("SignedTarget","1.0.0.0",token);
    else for(int i=0;i<(mode=="byte_budget" ? 100 : 4200);i++) c.WriteObservedException(true,false,"System.Exception",mode=="byte_budget" ? new string('x',100000) : "ordinary exception");
    var events=c.ReadEvents(mode,0,32,null)!;
    results[mode]=new {cursor,earliest_cursor=events.EarliestCursor,events_lost=events.EventsLost,readable=c.ReadStrongNameFailure(mode,cursor) is not null,consumed=Consume(c,mode,cursor)};
}

var restart=Start("restart"); var oldCursor=Record(restart,"restart");
var admission=restart.TryBeginControl(ControlOperation.Restart,"restart");
if(!admission.Admitted || !restart.MarkControlIssued(admission.Record!) || restart.ObserveProcessRemoved("restart",1,true,0).Outcome!="pending-restart" || !restart.BeginRestartRelaunch() || !restart.MarkLaunchClaimSucceeded(false,null)) throw new Exception("restart failed");
bool beforeRead=restart.ReadStrongNameFailure("restart",oldCursor) is not null;
bool beforeConsume=Consume(restart,"restart",oldCursor);
var newCursor=Record(restart,"restart");
var stale=restart.ReadStrongNameFailure("restart",oldCursor);
results["restart"]=new {old_cursor=oldCursor,new_cursor=newCursor,current_generation=restart.Generation,before_new_observation_readable=beforeRead,before_new_observation_consumed=beforeConsume,after_new_observation_readable=stale is not null,old_observation_generation=stale?.Generation,after_new_observation_consumed=Consume(restart,"restart",oldCursor),new_observation_consumed=Consume(restart,"restart",newCursor)};
var once=Start("once");var onceCursor=Record(once,"once");
results["one_shot"]=new {first=Consume(once,"once",onceCursor),second=Consume(once,"once",onceCursor),unknown_cursor=Consume(once,"once",9999),cross_session=Consume(once,"other",onceCursor)};
Console.WriteLine(JsonSerializer.Serialize(results,new JsonSerializerOptions{WriteIndented=true}));
