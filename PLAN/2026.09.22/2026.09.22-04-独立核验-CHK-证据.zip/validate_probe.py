from pathlib import Path
import json
from jsonschema import Draft202012Validator
base=Path(__file__).resolve().parent
root=base.parents[1]
raw=(base/'probe-run.txt').read_text()
r=json.loads(raw[raw.index('{\n'):])
(base/'probe-result.json').write_text(json.dumps(r,ensure_ascii=False,indent=2))
schema=json.loads((root/'tests/debug/contracts/dnspy.debug.v1.schema.json').read_text())
errors=[e.message for e in Draft202012Validator({'$ref':'#/$defs/event_exception','$defs':schema['$defs']}).iter_errors(r['exception_payload'])]
(base/'schema-result.json').write_text(json.dumps({'valid':not errors,'errors':errors,'payload':r['exception_payload']},indent=2))
assert not errors
assert r['present_thread_projection']=='th-1' and r['absent_thread_projection'] is None
c=r['classifier']
assert c['exact_identity_accepted']
for k in ['attribution_alone_accepted','version_drift_accepted','token_drift_accepted','nonreferenced_identity_accepted','already_loaded_accepted','wrong_hresult_accepted','no_identity_accepted']: assert not c[k],k
assert c['sample_module_synthetic_message_accepted'] and c['null_module_synthetic_message_accepted']
assert c['documentation_variant_accepted']
for mode in ['repeat_strong_name','ordinary_events','byte_budget']:
    d=r[mode]
    assert d['cursor'] < d['earliest_cursor']
    assert d['consumed']==(mode!='repeat_strong_name')
    assert d['readable']==(mode!='repeat_strong_name')
d=r['restart']
assert not d['before_new_observation_readable'] and not d['before_new_observation_consumed']
assert d['after_new_observation_readable'] and d['after_new_observation_consumed']
assert d['old_observation_generation']==1 and d['current_generation']==2 and d['new_observation_consumed']
assert r['one_shot']=={'first':True,'second':False,'unknown_cursor':False,'cross_session':False}
print('CHK-01 and CHK-03 fixes verified; CHK-02 synthetic provenance and CHK-04 stale-cursor/generation counterexamples reproduced. Product verdict: FAIL.')
